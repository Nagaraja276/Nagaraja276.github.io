"use client";

import { useState, useEffect, useMemo, useRef, useCallback } from "react";
import {
  philosophers,
  traditions,
  eras,
  eraBlurb,
  allPublicDomainQuotes,
  type Philosopher,
  type Tradition,
  type Era,
} from "@/lib/philosophers";
import {
  Search,
  Sparkles,
  Bookmark,
  BookmarkCheck,
  X,
  Shuffle,
  Copy,
  Quote as QuoteIcon,
  ScrollText,
  Compass,
  Filter,
  Globe2,
  Clock,
  Library,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast, Toaster } from "sonner";

const traditionAccentClass: Record<Tradition, string> = {
  Western: "accent-western",
  Chinese: "accent-chinese",
  Indian: "accent-indian",
  Buddhist: "accent-buddhist",
  Japanese: "accent-japanese",
  Islamic: "accent-islamic",
  Jewish: "accent-jewish",
  African: "accent-african",
  Indigenous: "accent-indigenous",
  "Latin American": "accent-latin-american",
};

const traditionDotColor: Record<Tradition, string> = {
  Western: "#d4a857",
  Chinese: "#c5471f",
  Indian: "#e89834",
  Buddhist: "#f0c75e",
  Japanese: "#b83a3a",
  Islamic: "#2d7d5f",
  Jewish: "#6b8cae",
  African: "#d97757",
  Indigenous: "#7a8c4f",
  "Latin American": "#5fa888",
};

export default function Home() {
  // ----- state -----
  const [search, setSearch] = useState("");
  const [activeEra, setActiveEra] = useState<Era | "All">("All");
  const [activeTradition, setActiveTradition] = useState<Tradition | "All">("All");
  const [selected, setSelected] = useState<Philosopher | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [quoteIdx, setQuoteIdx] = useState(0);
  const [randomQuote, setRandomQuote] = useState<string | null>(null);
  const [visibleCount, setVisibleCount] = useState(12);
  const heroRef = useRef<HTMLDivElement>(null);

  // ----- load favorites from localStorage (one-time on mount) -----
  useEffect(() => {
    try {
      const raw = localStorage.getItem("phil-favorites");
      if (raw) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setFavorites(new Set(JSON.parse(raw)));
      }
    } catch {
      /* ignore */
    }
  }, []);

  // ----- persist favorites -----
  useEffect(() => {
    try {
      localStorage.setItem("phil-favorites", JSON.stringify([...favorites]));
    } catch {
      /* ignore */
    }
  }, [favorites]);

  // ----- scroll-reveal observer -----
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            observer.unobserve(e.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" },
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [visibleCount, search, activeEra, activeTradition, showFavoritesOnly]);

  // ----- quote carousel rotation -----
  useEffect(() => {
    if (allPublicDomainQuotes.length === 0) return;
    const id = setInterval(() => {
      setQuoteIdx((i) => (i + 1) % allPublicDomainQuotes.length);
    }, 9000);
    return () => clearInterval(id);
  }, []);

  // ----- wrapped setters that also reset pagination -----
  const updateSearch = useCallback((val: string) => {
    setSearch(val);
    setVisibleCount(12);
  }, []);
  const updateEra = useCallback((era: Era | "All") => {
    setActiveEra(era);
    setVisibleCount(12);
  }, []);
  const updateTradition = useCallback((t: Tradition | "All") => {
    setActiveTradition(t);
    setVisibleCount(12);
  }, []);
  const toggleShowFavorites = useCallback(() => {
    setShowFavoritesOnly((v) => !v);
    setVisibleCount(12);
  }, []);

  // ----- derived: filtered philosophers -----
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return philosophers.filter((p) => {
      if (activeEra !== "All" && p.era !== activeEra) return false;
      if (activeTradition !== "All" && p.tradition !== activeTradition) return false;
      if (showFavoritesOnly && !favorites.has(p.id)) return false;
      if (!q) return true;
      const haystack = [
        p.name,
        p.essence,
        p.summary,
        p.school,
        p.region,
        p.years,
        ...p.keyIdeas,
        ...p.works,
        ...p.quotes.map((q) => q.text),
      ]
        .join(" ")
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [search, activeEra, activeTradition, showFavoritesOnly, favorites]);

  const visiblePhilosophers = filtered.slice(0, visibleCount);

  // ----- handlers -----
  const toggleFavorite = useCallback((id: string) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        toast("Removed from your atlas");
      } else {
        next.add(id);
        toast("Added to your atlas");
      }
      return next;
    });
  }, []);

  const copyQuote = useCallback(async (text: string, philosopher: string) => {
    const full = `"${text}" — ${philosopher}`;
    try {
      await navigator.clipboard.writeText(full);
      toast("Quote copied to clipboard");
    } catch {
      // Fallback
      const ta = document.createElement("textarea");
      ta.value = full;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
        toast("Quote copied to clipboard");
      } catch {
        toast("Could not copy — please select manually");
      }
      document.body.removeChild(ta);
    }
  }, []);

  const pickRandomQuote = useCallback(() => {
    const pool = allPublicDomainQuotes;
    if (pool.length === 0) return;
    const next = pool[Math.floor(Math.random() * pool.length)];
    setRandomQuote(`${next.text}|||${next.philosopher}|||${next.source}`);
  }, []);

  // ----- stats -----
  const stats = useMemo(
    () => ({
      thinkers: philosophers.length,
      traditions: traditions.length,
      eras: eras.length,
      quotes: allPublicDomainQuotes.length,
    }),
    [],
  );

  return (
    <div className="twinkle-bg relative min-h-screen overflow-x-hidden">
      {/* ============================================================
          HERO
          ============================================================ */}
      <header ref={heroRef} className="relative z-10 px-6 pt-20 pb-12 md:pt-28 md:pb-16">
        {/* Slow rotating ornament behind hero */}
        <div
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-32 -z-0 -translate-x-1/2 opacity-30 md:top-40"
        >
          <div className="rotate-slow relative h-[420px] w-[420px] md:h-[620px] md:w-[620px]">
            <svg viewBox="0 0 600 600" className="h-full w-full">
              <defs>
                <radialGradient id="ringGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="rgba(212,168,87,0)" />
                  <stop offset="70%" stopColor="rgba(212,168,87,0.15)" />
                  <stop offset="100%" stopColor="rgba(212,168,87,0)" />
                </radialGradient>
              </defs>
              <circle cx="300" cy="300" r="280" fill="url(#ringGrad)" />
              <circle
                cx="300"
                cy="300"
                r="280"
                fill="none"
                stroke="rgba(212,168,87,0.25)"
                strokeWidth="1"
                strokeDasharray="2 8"
              />
              <circle
                cx="300"
                cy="300"
                r="220"
                fill="none"
                stroke="rgba(212,168,87,0.18)"
                strokeWidth="1"
              />
              <circle
                cx="300"
                cy="300"
                r="160"
                fill="none"
                stroke="rgba(139,44,26,0.18)"
                strokeWidth="1"
                strokeDasharray="1 12"
              />
              <circle
                cx="300"
                cy="300"
                r="100"
                fill="none"
                stroke="rgba(212,168,87,0.12)"
                strokeWidth="1"
              />
              {/* tick marks on outer ring */}
              {Array.from({ length: 48 }).map((_, i) => {
                const angle = (i / 48) * Math.PI * 2;
                const r1 = 280;
                const r2 = i % 4 === 0 ? 268 : 274;
                const x1 = 300 + Math.cos(angle) * r1;
                const y1 = 300 + Math.sin(angle) * r1;
                const x2 = 300 + Math.cos(angle) * r2;
                const y2 = 300 + Math.sin(angle) * r2;
                return (
                  <line
                    key={i}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="rgba(212,168,87,0.4)"
                    strokeWidth={i % 4 === 0 ? 1.2 : 0.6}
                  />
                );
              })}
              {/* Zodiac-like glyphs around the ring (decorative, generic) */}
              {Array.from({ length: 12 }).map((_, i) => {
                const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
                const r = 245;
                const x = 300 + Math.cos(angle) * r;
                const y = 300 + Math.sin(angle) * r;
                return (
                  <circle
                    key={`g-${i}`}
                    cx={x}
                    cy={y}
                    r="2"
                    fill="rgba(245,203,111,0.8)"
                    className="pulse-slow"
                    style={{ animationDelay: `${i * 0.3}s` }}
                  />
                );
              })}
            </svg>
          </div>
        </div>

        <div className="mx-auto max-w-5xl text-center">
          <div className="mb-6 flex items-center justify-center gap-3 text-cosmic-gold">
            <span className="h-px w-12 bg-gradient-to-r from-transparent to-amber-500/60" />
            <Compass className="h-5 w-5" strokeWidth={1.5} />
            <span className="font-serif-display text-sm italic tracking-[0.3em] uppercase">
              An Atlas of Human Thought
            </span>
            <span className="h-px w-12 bg-gradient-to-l from-transparent to-amber-500/60" />
          </div>

          <h1 className="font-serif-display text-5xl font-light leading-[1.05] tracking-tight md:text-7xl lg:text-8xl">
            <span className="text-cream-gradient block">All Philosophy</span>
            <span className="text-gold-gradient block italic">Ever Made</span>
          </h1>

          <p className="mx-auto mt-8 max-w-2xl font-serif-display text-lg font-light leading-relaxed text-cosmic-muted md:text-xl">
            A wandering constellation of two and a half millennia of human inquiry — from
            <span className="text-cosmic-cream"> Heraclitus</span> by the river, to
            <span className="text-cosmic-cream"> Confucius</span> in the schoolyard, to
            <span className="text-cosmic-cream"> de Beauvoir</span> rewriting what a self can be.
          </p>

          {/* Stats strip */}
          <div className="mx-auto mt-10 grid max-w-2xl grid-cols-2 gap-4 md:grid-cols-4">
            {[
              { value: stats.thinkers, label: "Thinkers" },
              { value: stats.traditions, label: "Traditions" },
              { value: stats.eras, label: "Eras" },
              { value: stats.quotes, label: "Quotations" },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <div className="font-serif-display text-3xl font-medium text-cosmic-gold md:text-4xl">
                  {s.value}
                </div>
                <div className="mt-1 text-xs uppercase tracking-[0.2em] text-cosmic-muted">
                  {s.label}
                </div>
              </div>
            ))}
          </div>

          {/* CTA row */}
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <Button
              onClick={pickRandomQuote}
              size="lg"
              className="group bg-gradient-to-br from-amber-600/90 to-amber-800/90 text-amber-50 hover:from-amber-500 hover:to-amber-700"
            >
              <Shuffle className="mr-2 h-4 w-4 transition-transform group-hover:rotate-180 duration-500" />
              I'm feeling philosophical
            </Button>
            <a
              href="#explore"
              className="inline-flex h-11 items-center rounded-md border border-amber-700/40 px-6 text-sm text-cosmic-cream transition hover:border-amber-500/60 hover:bg-amber-500/5"
            >
              <Library className="mr-2 h-4 w-4" />
              Begin the wander
            </a>
          </div>
        </div>
      </header>

      {/* ============================================================
          QUOTE OF THE MOMENT
          ============================================================ */}
      <section className="relative z-10 px-6 pb-12">
        <div className="mx-auto max-w-4xl">
          <div className="glass-panel relative overflow-hidden rounded-2xl p-8 md:p-12">
            <div className="pointer-events-none absolute -top-12 left-8 text-amber-500/10">
              <QuoteIcon className="h-32 w-32" strokeWidth={1} />
            </div>
            <div className="relative">
              <div className="mb-4 flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-cosmic-gold">
                <Sparkles className="h-3 w-3" />
                <span>Quote of the moment</span>
              </div>
              {allPublicDomainQuotes[quoteIdx] && (
                <blockquote
                  key={quoteIdx}
                  className="quote-enter font-serif-display text-2xl font-light italic leading-snug text-cosmic-cream md:text-3xl"
                >
                  &ldquo;{allPublicDomainQuotes[quoteIdx].text}&rdquo;
                  <footer className="mt-5 text-base not-italic text-cosmic-muted">
                    <span className="text-cosmic-gold">— {allPublicDomainQuotes[quoteIdx].philosopher}</span>
                    <span className="mx-2 text-cosmic-muted/50">·</span>
                    <span className="text-sm">{allPublicDomainQuotes[quoteIdx].source}</span>
                  </footer>
                </blockquote>
              )}
              {/* carousel dots */}
              <div className="mt-8 flex flex-wrap gap-1.5">
                {allPublicDomainQuotes.slice(0, 24).map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setQuoteIdx(i)}
                    aria-label={`Show quote ${i + 1}`}
                    className={`h-1.5 rounded-full transition-all ${
                      i === quoteIdx ? "w-6 bg-amber-500" : "w-1.5 bg-amber-700/40 hover:bg-amber-600/60"
                    }`}
                  />
                ))}
                {allPublicDomainQuotes.length > 24 && (
                  <span className="ml-2 text-xs text-cosmic-muted">
                    +{allPublicDomainQuotes.length - 24} more
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================
          FILTER BAR (sticky)
          ============================================================ */}
      <section id="explore" className="sticky top-0 z-30 px-6 py-4">
        <div className="glass-panel mx-auto max-w-7xl rounded-2xl p-4 shadow-2xl">
          {/* search row */}
          <div className="flex flex-col gap-3 md:flex-row md:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-cosmic-muted" />
              <Input
                type="text"
                value={search}
                onChange={(e) => updateSearch(e.target.value)}
                placeholder="Search by name, idea, work, or word…"
                className="border-amber-900/40 bg-black/40 pl-10 text-cosmic-cream placeholder:text-cosmic-muted/70 focus:border-amber-500/60"
              />
              {search && (
                <button
                  onClick={() => updateSearch("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-cosmic-muted hover:text-cosmic-cream"
                  aria-label="Clear search"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <Button
              variant={showFavoritesOnly ? "default" : "outline"}
              onClick={toggleShowFavorites}
              className={
                showFavoritesOnly
                  ? "border-amber-500 bg-amber-600/20 text-cosmic-gold hover:bg-amber-600/30"
                  : "border-amber-900/40 text-cosmic-muted hover:text-cosmic-cream"
              }
            >
              {showFavoritesOnly ? <BookmarkCheck className="mr-2 h-4 w-4" /> : <Bookmark className="mr-2 h-4 w-4" />}
              {showFavoritesOnly ? `${favorites.size} saved` : "Saved"}
            </Button>
          </div>

          {/* Era pills */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="mr-1 flex items-center gap-1 text-xs uppercase tracking-wider text-cosmic-muted">
              <Clock className="h-3 w-3" /> Era
            </span>
            <FilterPill active={activeEra === "All"} onClick={() => updateEra("All")}>
              All
            </FilterPill>
            {eras.map((era) => (
              <FilterPill key={era} active={activeEra === era} onClick={() => updateEra(era)}>
                {era}
              </FilterPill>
            ))}
          </div>

          {/* Tradition chips */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="mr-1 flex items-center gap-1 text-xs uppercase tracking-wider text-cosmic-muted">
              <Globe2 className="h-3 w-3" /> Tradition
            </span>
            <FilterPill active={activeTradition === "All"} onClick={() => updateTradition("All")}>
              All
            </FilterPill>
            {traditions.map((t) => (
              <button
                key={t}
                onClick={() => updateTradition(activeTradition === t ? "All" : t)}
                className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs transition ${
                  activeTradition === t
                    ? "border-amber-500/60 bg-amber-500/15 text-cosmic-cream"
                    : "border-amber-900/30 text-cosmic-muted hover:border-amber-700/50 hover:text-cosmic-cream"
                }`}
              >
                <span
                  className="h-2 w-2 rounded-full"
                  style={{ backgroundColor: traditionDotColor[t] }}
                />
                {t}
              </button>
            ))}
          </div>

          {/* result count */}
          <div className="mt-3 flex items-center gap-2 text-xs text-cosmic-muted">
            <Filter className="h-3 w-3" />
            <span>
              {filtered.length} {filtered.length === 1 ? "thinker" : "thinkers"}
              {activeEra !== "All" && ` · ${activeEra} era`}
              {activeTradition !== "All" && ` · ${activeTradition} tradition`}
            </span>
          </div>
        </div>
      </section>

      {/* ============================================================
          PHILOSOPHER GRID
          ============================================================ */}
      <main className="relative z-10 px-6 py-12">
        <div className="mx-auto max-w-7xl">
          {filtered.length === 0 ? (
            <div className="py-24 text-center">
              <div className="mb-4 text-5xl">⌖</div>
              <p className="font-serif-display text-2xl text-cosmic-cream">No thinkers match your query.</p>
              <p className="mt-2 text-cosmic-muted">Try a different word, or clear your filters.</p>
              <Button
                variant="outline"
                className="mt-6 border-amber-700/40 text-cosmic-cream"
                onClick={() => {
                  updateSearch("");
                  updateEra("All");
                  updateTradition("All");
                  setShowFavoritesOnly(false);
                }}
              >
                Reset everything
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {visiblePhilosophers.map((p, i) => (
                <PhilosopherCard
                  key={p.id}
                  philosopher={p}
                  index={i}
                  isFavorite={favorites.has(p.id)}
                  onToggleFavorite={() => toggleFavorite(p.id)}
                  onOpen={() => setSelected(p)}
                />
              ))}
            </div>
          )}

          {/* Load more */}
          {visibleCount < filtered.length && (
            <div className="mt-10 flex justify-center">
              <Button
                variant="outline"
                size="lg"
                onClick={() => setVisibleCount((c) => c + 12)}
                className="border-amber-700/40 text-cosmic-cream hover:bg-amber-500/10"
              >
                Reveal {Math.min(12, filtered.length - visibleCount)} more
                <span className="ml-2 text-cosmic-muted">
                  ({filtered.length - visibleCount} remaining)
                </span>
              </Button>
            </div>
          )}
        </div>
      </main>

      {/* ============================================================
          FOOTER
          ============================================================ */}
      <footer className="relative z-10 mt-12 border-t border-amber-900/20 px-6 py-12">
        <div className="mx-auto max-w-4xl text-center">
          <div className="ornament-divider mx-auto mb-8 max-w-md" />
          <div className="font-serif-display text-2xl italic text-cosmic-gold">
            The unexamined life is not worth living.
          </div>
          <div className="mt-2 text-sm text-cosmic-muted">— Socrates, Apology 38a</div>

          <div className="mt-10 grid gap-6 text-sm text-cosmic-muted md:grid-cols-3">
            <div>
              <div className="mb-2 flex items-center justify-center gap-2 text-cosmic-cream">
                <ScrollText className="h-4 w-4" />
                <span className="font-medium">On copyright</span>
              </div>
              <p className="leading-relaxed">
                Direct quotations are drawn exclusively from public-domain translations of pre-1900
                thinkers. For 20th-century philosophers whose works remain under copyright
                (Wittgenstein, Heidegger, Sartre, Camus, de Beauvoir, Arendt, Foucault, Rawls, and
                Rumi via Barks), only paraphrased summaries are given — never copyrighted translated
                wording.
              </p>
            </div>
            <div>
              <div className="mb-2 flex items-center justify-center gap-2 text-cosmic-cream">
                <Compass className="h-4 w-4" />
                <span className="font-medium">On attribution</span>
              </div>
              <p className="leading-relaxed">
                A few commonly misattributed &ldquo;folk quotes&rdquo; — notably the Buddha&rsquo;s
                &ldquo;hot coal&rdquo; line and several Confucius attributions — are flagged as
                paraphrases. Use the verified alternatives cited in each entry when quoting in
                public-facing work.
              </p>
            </div>
            <div>
              <div className="mb-2 flex items-center justify-center gap-2 text-cosmic-cream">
                <Library className="h-4 w-4" />
                <span className="font-medium">A living atlas</span>
              </div>
              <p className="leading-relaxed">
                This is an invitation, not a canon. Every tradition represented here contains
                thousands more voices. Wander, bookmark, follow what stirs you back to the
                original texts — that is the only way an atlas of thought is meant to be used.
              </p>
            </div>
          </div>

          <div className="mt-10 text-xs text-cosmic-muted/70">
            Built with care · {philosophers.length} thinkers across {traditions.length} traditions ·
            All direct quotations from public-domain sources
          </div>
        </div>
      </footer>

      {/* ============================================================
          PHILOSOPHER DETAIL DIALOG
          ============================================================ */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto border-amber-900/40 bg-gradient-to-br from-[#161311] to-[#0a0908] p-0 sm:max-w-3xl">
          {selected && (
            <div className={`${traditionAccentClass[selected.tradition]} relative`}>
              {/* Top accent bar */}
              <div
                className="h-1.5 w-full"
                style={{ backgroundColor: traditionDotColor[selected.tradition] }}
              />
              <div className="p-6 md:p-10">
                <DialogHeader className="mb-6 space-y-2 text-left">
                  <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.2em] text-cosmic-muted">
                    <span>{selected.era}</span>
                    <span className="text-cosmic-muted/40">·</span>
                    <span>{selected.years}</span>
                    <span className="text-cosmic-muted/40">·</span>
                    <span>{selected.region}</span>
                  </div>
                  <DialogTitle className="font-serif-display text-4xl font-light text-cosmic-cream md:text-5xl">
                    {selected.name}
                  </DialogTitle>
                  <DialogDescription className="font-serif-display text-lg italic text-cosmic-gold">
                    {selected.school}
                  </DialogDescription>
                </DialogHeader>

                {/* Essence */}
                <div className="mb-6 border-l-2 border-amber-600/40 pl-4">
                  <div className="font-serif-display text-xl italic leading-relaxed text-cosmic-cream">
                    &ldquo;{selected.essence}&rdquo;
                  </div>
                </div>

                {/* Summary */}
                <section className="mb-6">
                  <SectionLabel icon={<ScrollText className="h-3 w-3" />}>Orientation</SectionLabel>
                  <p className="leading-relaxed text-cosmic-cream/90">{selected.summary}</p>
                </section>

                {/* Key ideas */}
                <section className="mb-6">
                  <SectionLabel icon={<Sparkles className="h-3 w-3" />}>Key ideas</SectionLabel>
                  <ul className="space-y-2">
                    {selected.keyIdeas.map((idea, i) => (
                      <li key={i} className="flex gap-3 text-sm leading-relaxed text-cosmic-cream/90">
                        <span
                          className="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full"
                          style={{ backgroundColor: traditionDotColor[selected.tradition] }}
                        />
                        <span>{idea}</span>
                      </li>
                    ))}
                  </ul>
                </section>

                {/* Major works */}
                <section className="mb-6">
                  <SectionLabel icon={<Library className="h-3 w-3" />}>Major works</SectionLabel>
                  <div className="flex flex-wrap gap-2">
                    {selected.works.map((w, i) => (
                      <Badge
                        key={i}
                        variant="outline"
                        className="border-amber-800/40 bg-amber-950/20 text-cosmic-cream"
                      >
                        {w}
                      </Badge>
                    ))}
                  </div>
                </section>

                {/* Quotes */}
                {selected.quotes.length > 0 && (
                  <section className="mb-2">
                    <SectionLabel icon={<QuoteIcon className="h-3 w-3" />}>
                      Quotes{" "}
                      <span className="ml-1 text-cosmic-muted">
                        ({selected.quotes.filter((q) => q.kind === "public-domain").length} public-domain ·{" "}
                        {selected.quotes.filter((q) => q.kind === "paraphrase").length} paraphrase)
                      </span>
                    </SectionLabel>
                    <div className="space-y-3">
                      {selected.quotes.map((q, i) => (
                        <div
                          key={i}
                          className="group relative rounded-lg border border-amber-900/30 bg-black/30 p-4"
                        >
                          <div className="font-serif-display text-lg italic leading-relaxed text-cosmic-cream">
                            &ldquo;{q.text}&rdquo;
                          </div>
                          <div className="mt-3 flex items-start justify-between gap-3 text-xs text-cosmic-muted">
                            <span className="leading-relaxed">
                              {q.source}
                              {q.kind === "paraphrase" && (
                                <span className="ml-2 rounded bg-amber-950/40 px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-amber-400/70">
                                  Paraphrase
                                </span>
                              )}
                            </span>
                            <button
                              onClick={() => copyQuote(q.text, selected.name)}
                              className="flex-shrink-0 text-cosmic-muted transition hover:text-cosmic-gold"
                              aria-label="Copy quote"
                            >
                              <Copy className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </section>
                )}

                {/* Actions */}
                <div className="mt-8 flex items-center gap-3 border-t border-amber-900/20 pt-6">
                  <Button
                    variant={favorites.has(selected.id) ? "default" : "outline"}
                    onClick={() => toggleFavorite(selected.id)}
                    className={
                      favorites.has(selected.id)
                        ? "bg-amber-600/30 text-cosmic-gold hover:bg-amber-600/40"
                        : "border-amber-700/40 text-cosmic-cream hover:bg-amber-500/10"
                    }
                  >
                    {favorites.has(selected.id) ? (
                      <BookmarkCheck className="mr-2 h-4 w-4" />
                    ) : (
                      <Bookmark className="mr-2 h-4 w-4" />
                    )}
                    {favorites.has(selected.id) ? "Saved to atlas" : "Save to atlas"}
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => setSelected(null)}
                    className="text-cosmic-muted hover:text-cosmic-cream"
                  >
                    Close
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ============================================================
          RANDOM QUOTE DIALOG
          ============================================================ */}
      <Dialog open={!!randomQuote} onOpenChange={(o) => !o && setRandomQuote(null)}>
        <DialogContent className="border-amber-900/40 bg-gradient-to-br from-[#161311] to-[#0a0908] sm:max-w-2xl">
          {randomQuote && (
            <div className="text-center">
              <div className="mb-4 flex items-center justify-center gap-2 text-xs uppercase tracking-[0.3em] text-cosmic-gold">
                <Sparkles className="h-3 w-3" />
                A random spark
              </div>
              <QuoteIcon className="mx-auto mb-6 h-10 w-10 text-amber-500/30" strokeWidth={1} />
              <blockquote className="font-serif-display text-2xl font-light italic leading-relaxed text-cosmic-cream md:text-3xl">
                &ldquo;{randomQuote.split("|||")[0]}&rdquo;
              </blockquote>
              <div className="mt-6 text-cosmic-gold">
                — {randomQuote.split("|||")[1]}
              </div>
              <div className="mt-1 text-xs text-cosmic-muted">
                {randomQuote.split("|||")[2]}
              </div>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Button
                  onClick={pickRandomQuote}
                  className="bg-gradient-to-br from-amber-600/90 to-amber-800/90 text-amber-50 hover:from-amber-500 hover:to-amber-700"
                >
                  <Shuffle className="mr-2 h-4 w-4" />
                  Another
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    const [text, phil] = randomQuote.split("|||");
                    copyQuote(text, phil);
                  }}
                  className="border-amber-700/40 text-cosmic-cream hover:bg-amber-500/10"
                >
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => setRandomQuote(null)}
                  className="text-cosmic-muted hover:text-cosmic-cream"
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Toaster />
    </div>
  );
}

/* ============================================================
   Sub-components
   ============================================================ */

function FilterPill({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1 text-xs transition ${
        active
          ? "border-amber-500/60 bg-amber-500/15 text-cosmic-cream"
          : "border-amber-900/30 text-cosmic-muted hover:border-amber-700/50 hover:text-cosmic-cream"
      }`}
    >
      {children}
    </button>
  );
}

function SectionLabel({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-cosmic-gold">
      {icon}
      <span>{children}</span>
      <span className="ornament-divider ml-2 flex-1" />
    </div>
  );
}

function PhilosopherCard({
  philosopher: p,
  index,
  isFavorite,
  onToggleFavorite,
  onOpen,
}: {
  philosopher: Philosopher;
  index: number;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  onOpen: () => void;
}) {
  const accent = traditionDotColor[p.tradition];
  return (
    <article
      className={`card-cosmic reveal group relative flex cursor-pointer flex-col rounded-xl p-5 ${
        traditionAccentClass[p.tradition]
      }`}
      style={{ transitionDelay: `${Math.min(index * 40, 400)}ms` }}
      onClick={onOpen}
    >
      {/* Top row: tradition dot + favorite */}
      <div className="mb-3 flex items-start justify-between">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: accent }} />
          <span className="text-[10px] uppercase tracking-[0.2em] text-cosmic-muted">
            {p.tradition}
          </span>
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite();
          }}
          className={`-mr-1 -mt-1 rounded p-1 transition ${
            isFavorite ? "text-amber-400" : "text-cosmic-muted/50 hover:text-cosmic-gold"
          }`}
          aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
        >
          {isFavorite ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
        </button>
      </div>

      {/* Name */}
      <h3 className="font-serif-display text-2xl font-medium leading-tight text-cosmic-cream">
        {p.name}
      </h3>

      {/* Meta */}
      <div className="mt-1 text-xs text-cosmic-muted">
        <span className="text-cosmic-gold/80">{p.school}</span>
        <span className="mx-1.5 text-cosmic-muted/40">·</span>
        <span>{p.years}</span>
      </div>

      {/* Essence */}
      <p className="mt-4 flex-1 font-serif-display text-base italic leading-relaxed text-cosmic-cream/85">
        {p.essence}
      </p>

      {/* Bottom row */}
      <div className="mt-5 flex items-center justify-between border-t border-amber-900/20 pt-3 text-xs text-cosmic-muted">
        <span className="flex items-center gap-1">
          <Clock className="h-3 w-3" />
          {p.era}
        </span>
        {p.quotes.length > 0 && (
          <span className="flex items-center gap-1">
            <QuoteIcon className="h-3 w-3" />
            {p.quotes.length} {p.quotes.length === 1 ? "quote" : "quotes"}
          </span>
        )}
      </div>

      {/* Hover hint */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center pb-2 opacity-0 transition group-hover:opacity-100">
        <span className="rounded-full bg-amber-500/10 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-cosmic-gold">
          Click to open →
        </span>
      </div>
    </article>
  );
}
