import type { Metadata } from "next";
import { Geist, Geist_Mono, Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const cormorant = Cormorant_Garamond({
  variable: "--font-serif-display",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  style: ["normal", "italic"],
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "The Atlas of Human Thought — A Cosmos of Philosophy",
  description:
    "An interactive journey through 2,500 years of human philosophy across Western, Eastern, Islamic, Jewish, African, Indigenous, and Latin American traditions. Quotes, key ideas, and biographies from Heraclitus to Foucault.",
  keywords: [
    "philosophy",
    "philosophers",
    "wisdom",
    "Stoicism",
    "Existentialism",
    "Confucius",
    "Buddha",
    "Plato",
    "Aristotle",
    "Nietzsche",
    "Eastern philosophy",
    "comparative philosophy",
  ],
  authors: [{ name: "Atlas of Human Thought" }],
  openGraph: {
    title: "The Atlas of Human Thought",
    description: "A cosmos of philosophy — 2,500 years of human wisdom, interactive.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "The Atlas of Human Thought",
    description: "A cosmos of philosophy — 2,500 years of human wisdom, interactive.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${cormorant.variable} ${inter.variable} antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
