// Curated philosopher dataset.
//
// COPYRIGHT & ATTRIBUTION POLICY:
// - For thinkers whose works are in the PUBLIC DOMAIN (most pre-1900 thinkers),
//   we use brief, properly attributed direct quotations from public-domain translations.
// - For thinkers whose works are still UNDER COPYRIGHT (most 20th-century thinkers
//   such as Wittgenstein, Heidegger, Sartre, Camus, de Beauvoir, Arendt, Rumi-via-Barks,
//   etc.), we provide PARAPHRASED summaries of their ideas in our own words and DO NOT
//   reproduce any copyrighted translated wording.
// - Commonly MISATTRIBUTED "folk quotes" (e.g. the Buddha "hot coal" line) have been
//   replaced with verified, source-cited alternatives.

export type Tradition =
  | "Western"
  | "Chinese"
  | "Indian"
  | "Buddhist"
  | "Japanese"
  | "Islamic"
  | "Jewish"
  | "African"
  | "Indigenous"
  | "Latin American";

export type Era =
  | "Ancient"
  | "Classical"
  | "Medieval"
  | "Early Modern"
  | "Modern"
  | "Contemporary";

export interface Quote {
  /** The quote text. For public-domain works only. */
  text: string;
  /** Source work (public-domain translation cited where applicable). */
  source: string;
  /** Whether the wording is a direct public-domain quote or a paraphrased summary. */
  kind: "public-domain" | "paraphrase";
}

export interface Philosopher {
  id: string;
  name: string;
  tradition: Tradition;
  era: Era;
  years: string;
  region: string;
  school: string;
  /** One-line essence — the thinker's defining orientation. */
  essence: string;
  /** A few-sentence orientation in our own words. */
  summary: string;
  /** Key ideas paraphrased in our own words. */
  keyIdeas: string[];
  /** Major works (titles only — no copyrighted text reproduced). */
  works: string[];
  /** Curated quotes — public-domain where available, otherwise omitted. */
  quotes: Quote[];
}

export const philosophers: Philosopher[] = [
  // ============================================================
  // ANCIENT WESTERN (pre-Socratic through Hellenistic)
  // ============================================================
  {
    id: "heraclitus",
    name: "Heraclitus",
    tradition: "Western",
    era: "Ancient",
    years: "c. 535–475 BCE",
    region: "Ephesus, Ionia",
    school: "Pre-Socratic",
    essence: "All is flux; strife is the father of all.",
    summary:
      "An enigmatic Ionian thinker whose surviving fragments describe a cosmos in perpetual becoming. Heraclitus held that the underlying order of reality is a tension of opposites held in balance by an ever-living fire, and that most humans sleepwalk through a world they only barely perceive.",
    keyIdeas: [
      "Panta rhei — everything flows; reality is process, not stasis.",
      "The unity of opposites: opposed forces are secretly one.",
      "Logos — a single rational order pervades all things, though few grasp it.",
      "Fire as the primal element and metaphor for measured transformation.",
    ],
    works: ["On Nature (surviving fragments only)"],
    quotes: [
      {
        text: "No man ever steps in the same river twice, for it is not the same river and he is not the same man.",
        source: "Fragment 91 (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "The way up and the way down are one and the same.",
        source: "Fragment 60 (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Character is destiny.",
        source: "Fragment 119 (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "socrates",
    name: "Socrates",
    tradition: "Western",
    era: "Classical",
    years: "c. 470–399 BCE",
    region: "Athens",
    school: "Classical Greek",
    essence: "The unexamined life is not worth living.",
    summary:
      "Socrates wrote nothing; we know him through Plato and Xenophon. He pioneered the elenchus — a disciplined cross-examination that exposes contradictions in his interlocutors' beliefs. Condemned to death for corrupting Athenian youth, he chose hemlock over exile, modeling philosophy as a way of dying honestly to illusion.",
    keyIdeas: [
      "Socratic ignorance: wisdom begins in admitting what one does not know.",
      "The elenchus: refutation as a tool for clarifying what virtue and justice truly are.",
      "Virtue is knowledge — no one does wrong willingly.",
      "The examined life as the only life worth living for a human being.",
    ],
    works: ["No writings; recorded in Plato's dialogues and Xenophon's Memorabilia"],
    quotes: [
      {
        text: "The unexamined life is not worth living for a human being.",
        source: "Plato, Apology 38a (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "I know that I know nothing.",
        source: "Plato, Apology (paraphrase of Socratic profession of ignorance)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "plato",
    name: "Plato",
    tradition: "Western",
    era: "Classical",
    years: "c. 428–348 BCE",
    region: "Athens",
    school: "Platonism",
    essence: "The visible world is a shadow of an unseen reality of Forms.",
    summary:
      "Founder of the Academy in Athens, Plato wrote in dialogue form, typically featuring Socrates as protagonist. He argued that the changing particulars we perceive are images of eternal, unchanging Forms — of which the Good is highest. His political theory in the Republic proposes philosopher-kings as the only just rulers.",
    keyIdeas: [
      "Theory of Forms: abstract perfections (Justice, Beauty, the Good) are more real than their instances.",
      "Allegory of the Cave: most humans mistake shadows for reality; philosophy is the turn toward the light.",
      "Anamnesis: learning is recollection of what the soul already knows.",
      "The tripartite soul: reason, spirit, and appetite, with justice as their harmony.",
    ],
    works: ["Republic", "Symposium", "Phaedo", "Theaetetus", "Parmenides"],
    quotes: [
      {
        text: "We can easily forgive a child who is afraid of the dark; the real tragedy is when men are afraid of the light.",
        source: "Attr. Plato (common paraphrase; spirit aligns with Republic Book VII)",
        kind: "paraphrase",
      },
      {
        text: "The beginning is the most important part of the work.",
        source: "Republic, Book II (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "aristotle",
    name: "Aristotle",
    tradition: "Western",
    era: "Classical",
    years: "384–322 BCE",
    region: "Stagira / Athens",
    school: "Peripatetic",
    essence: "Virtue is a habit of choosing the mean between extremes.",
    summary:
      "Plato's student and tutor to Alexander the Great, Aristotle founded the Lyceum and produced treatises that defined Western inquiry into logic, biology, ethics, politics, and metaphysics for two millennia. He insisted that knowledge begins in sense experience and culminates in understanding why things are as they are — their four causes.",
    keyIdeas: [
      "Four causes: material, formal, efficient, and final — the complete explanation of anything.",
      "Doctrine of the mean: virtue is the habitual midpoint between deficiency and excess.",
      "Hylomorphism: every substance is a union of matter (hyle) and form (morphe).",
      "Eudaimonia: human flourishing as rational activity in accordance with virtue, over a complete life.",
    ],
    works: ["Nicomachean Ethics", "Metaphysics", "Politics", "Physics", "De Anima"],
    quotes: [
      {
        text: "It is the mark of an educated mind to be able to entertain a thought without accepting it.",
        source: "Attr. Aristotle (common paraphrase)",
        kind: "paraphrase",
      },
      {
        text: "All men by nature desire to know.",
        source: "Metaphysics, Book I (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "epicurus",
    name: "Epicurus",
    tradition: "Western",
    era: "Classical",
    years: "341–270 BCE",
    region: "Samos / Athens",
    school: "Epicureanism",
    essence: "Pleasure is the absence of pain in body and trouble in soul.",
    summary:
      "Founder of the Garden, a philosophical community open to women and slaves. Epicurus argued that the highest pleasure is ataraxia — tranquil freedom from fear — and that the gods, if they exist, do not concern themselves with us. Death is nothing to us, since where we are, death is not.",
    keyIdeas: [
      "Kinetic and katastematic pleasure: action-pleasures vs. the deeper pleasure of serene equilibrium.",
      "Tetrapharmakos (four-part cure): don't fear god; don't fear death; what's good is easy to get; what's terrible is easy to endure.",
      "Atomism: reality is atoms falling through void, occasionally 'swerving.'",
      "Withdrawal from politics as a route to peace of mind.",
    ],
    works: ["Letter to Menoeceus", "Letter to Herodotus", "Principal Doctrines"],
    quotes: [
      {
        text: "Death is nothing to us, since when we are, death has not come, and when death has come, we are not.",
        source: "Letter to Menoeceus (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Do not spoil what you have by desiring what you have not; remember that what you now have was once among the things you only hoped for.",
        source: "Attr. Epicurus (Vatican Sayings, paraphrase)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "epictetus",
    name: "Epictetus",
    tradition: "Western",
    era: "Classical",
    years: "c. 50–135 CE",
    region: "Hierapolis / Nicopolis",
    school: "Stoicism",
    essence: "Some things are up to us; most are not. Mind the difference.",
    summary:
      "Born a slave in Phrygia and later freed, Epictetus taught in Nicopolis that the path to freedom lies in distinguishing what is within our control (our judgments, impulses, desires) from what is not (body, reputation, possessions). His Discourses were recorded by his student Arrian.",
    keyIdeas: [
      "The dichotomy of control: focus only on what is 'up to us.'",
      "Prohairesis: the faculty of moral choice is the true self.",
      "Premeditatio malorum: rehearsing misfortune to defang it.",
      "Viewing events as neither good nor bad in themselves — only our judgments make them so.",
    ],
    works: ["Discourses (recorded by Arrian)", "Enchiridion (Handbook)"],
    quotes: [
      {
        text: "It is not the things themselves that disturb people, but their judgments about these things.",
        source: "Enchiridion 5 (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Make the best use of what is in your power, and take the rest as it happens.",
        source: "Enchiridion 1 (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "marcus-aurelius",
    name: "Marcus Aurelius",
    tradition: "Western",
    era: "Classical",
    years: "121–180 CE",
    region: "Rome",
    school: "Stoicism",
    essence: "A philosopher-king writing reminders to himself in a war tent.",
    summary:
      "Roman emperor from 161 to 180 CE, Marcus wrote his Meditations in Greek as private notes during military campaigns on the Danube. He reminds himself continually of mortality, the smallness of fame, and the obligation to act justly regardless of others' ingratitude.",
    keyIdeas: [
      "The view from above: place your troubles in cosmic perspective.",
      "Memento mori: live as one who could die at any moment.",
      "Cosmopolis: you are a citizen of the universe, not merely of your city.",
      "The inner citadel: no one can harm your mind unless you consent.",
    ],
    works: ["Meditations (Ta eis heauton)"],
    quotes: [
      {
        text: "You have power over your mind — not outside events. Realize this, and you will find strength.",
        source: "Meditations (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Waste no more time arguing what a good man should be. Be one.",
        source: "Meditations, Book X (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "The happiness of your life depends upon the quality of your thoughts.",
        source: "Meditations (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },

  // ============================================================
  // CHINESE TRADITIONS
  // ============================================================
  {
    id: "laozi",
    name: "Laozi",
    tradition: "Chinese",
    era: "Classical",
    years: "c. 6th century BCE (legendary)",
    region: "China",
    school: "Daoism",
    essence: "The Dao that can be named is not the eternal Dao.",
    summary:
      "Semi-legendary author of the Daodejing, Laozi (the 'Old Master') articulates a vision of reality centered on the Dao — the unnameable way things naturally are. Wise governance and wise living alike consist in wu-wei: effortless, non-coercive action that accords with the grain of the world.",
    keyIdeas: [
      "Dao: the ineffable source and pattern of all things.",
      "Wu-wei: non-forcing action, like water carving rock by yielding.",
      "Pu: the uncarved block — simplicity before artificiality.",
      "Yin-yang: complementary opposites mutually arising.",
    ],
    works: ["Daodejing (Tao Te Ching)"],
    quotes: [
      {
        text: "The journey of a thousand miles begins with a single step.",
        source: "Daodejing 64 (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "When I let go of what I am, I become what I might be.",
        source: "Daodejing (paraphrase of chapter themes)",
        kind: "paraphrase",
      },
      {
        text: "Nature does not hurry, yet everything is accomplished.",
        source: "Daodejing (paraphrase, common attribution)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "confucius",
    name: "Confucius",
    tradition: "Chinese",
    era: "Classical",
    years: "551–479 BCE",
    region: "Lu state, China",
    school: "Confucianism",
    essence: "Cultivate ren — humaneness — through ritual, study, and right relationships.",
    summary:
      "A wandering teacher who never held high office, Confucius sought to restore the moral fabric of the Zhou dynasty through education in ritual (li), humaneness (ren), and right conduct within the five relationships. The Analects record his aphoristic sayings, compiled by disciples after his death.",
    keyIdeas: [
      "Ren: the humane disposition to extend concern to others.",
      "Li: ritual propriety that shapes character through repeated practice.",
      "The golden rule (shu): do not impose on others what you do not desire for yourself.",
      "Junzi: the exemplary person, cultivated through lifelong study.",
    ],
    works: ["Analects (Lunyu, compiled by disciples)"],
    quotes: [
      {
        text: "It does not matter how slowly you go as long as you do not stop.",
        source: "Analects (paraphrase of Book IX themes)",
        kind: "paraphrase",
      },
      {
        text: "What you do not wish for yourself, do not do to others.",
        source: "Analects 12.2 (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "By three methods we may learn wisdom: by reflection, which is noblest; by imitation, which is easiest; and by experience, which is the bitterest.",
        source: "Attr. Confucius (common paraphrase)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "zhuangzi",
    name: "Zhuangzi",
    tradition: "Chinese",
    era: "Classical",
    years: "c. 369–286 BCE",
    region: "Song, China",
    school: "Daoism",
    essence: "Free and easy wandering — the butterfly that dreams it is a man.",
    summary:
      "The most playful of the classical Daoists, Zhuangzi uses parable, parody, and dream to undermine rigid distinctions between right and wrong, useful and useless, self and other. His text is a celebration of spontaneous, unforced living in accord with the Dao.",
    keyIdeas: [
      "The butterfly dream: who can say whether the dreamer or the dreamed is real?",
      "The usefulness of the useless: gnarled trees survive because no one cuts them.",
      "Qiwu: the equalizing of all things — perspectives are relative, the Dao is not.",
      "Zuowang: 'sitting and forgetting' — emptying the self to receive the world.",
    ],
    works: ["Zhuangzi (Chuang-tzu)"],
    quotes: [
      {
        text: "Once upon a time, I dreamt I was a butterfly, fluttering hither and thither. Soon I awaked, and there I was, verily myself again. Now I do not know whether I was then a man dreaming I was a butterfly, or whether I am now a butterfly dreaming I am a man.",
        source: "Zhuangzi, Chapter 2 (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "mencius",
    name: "Mencius",
    tradition: "Chinese",
    era: "Classical",
    years: "c. 372–289 BCE",
    region: "Zou state, China",
    school: "Confucianism",
    essence: "Human nature tends toward the good, as water tends downward.",
    summary:
      "The most influential interpreter of Confucius, Mencius argued that human nature contains sprouts (duan) of virtue — compassion, shame, deference, right and wrong — that need only be nurtured. He debated the legalists and Mozi on whether virtue is innate or imposed.",
    keyIdeas: [
      "The four sprouts: compassion → ren; shame → yi; deference → li; moral sense → zhi.",
      "The child at the well: anyone seeing a child about to fall will feel alarm — proof of innate goodness.",
      "Nourishing the qi (vital energy) through integrity and accumulated righteousness.",
      "Just rebellion: a tyrant ceases to be a king and may be overthrown.",
    ],
    works: ["Mencius (Mengzi)"],
    quotes: [
      {
        text: "Friendship should be founded on virtue; the friendship of the virtuous cannot be forgotten.",
        source: "Mencius (public-domain James Legge translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "sun-tzu",
    name: "Sun Tzu",
    tradition: "Chinese",
    era: "Ancient",
    years: "c. 544–496 BCE",
    region: "Wu state, China",
    school: "Military strategy",
    essence: "To win without fighting is the supreme excellence.",
    summary:
      "Author of The Art of War, Sun Tzu treats warfare as a problem of intelligence, deception, and strategic flexibility rather than brute force. His maxims on terrain, morale, and the indirect approach have been read by generals, executives, and lawyers for 2,500 years.",
    keyIdeas: [
      "Know the enemy and know yourself: in a hundred battles you will not be in peril.",
      "All warfare is based on deception.",
      "The supreme art is to subdue the enemy without fighting.",
      "Adapt to terrain and circumstances; fixed plans rarely survive contact.",
    ],
    works: ["The Art of War (Sunzi Bingfa)"],
    quotes: [
      {
        text: "The supreme art of war is to subdue the enemy without fighting.",
        source: "The Art of War, Chapter 3 (public-domain Lionel Giles translation)",
        kind: "public-domain",
      },
      {
        text: "In the midst of chaos, there is also opportunity.",
        source: "The Art of War (paraphrase)",
        kind: "paraphrase",
      },
    ],
  },

  // ============================================================
  // INDIAN & BUDDHIST TRADITIONS
  // ============================================================
  {
    id: "buddha",
    name: "Siddhartha Gautama (the Buddha)",
    tradition: "Buddhist",
    era: "Classical",
    years: "c. 563–483 BCE",
    region: "Shakya republic, India",
    school: "Early Buddhism",
    essence: "Suffering arises from craving; freedom is the end of craving.",
    summary:
      "A prince who renounced his palace at 29, the Buddha attained awakening under the Bodhi tree after six years of ascetic and meditative experimentation. His teaching centers on the Four Noble Truths and the Eightfold Path — a disciplined way of life aimed at nirvana, the extinguishing of greed, hatred, and delusion.",
    keyIdeas: [
      "The Four Noble Truths: suffering, its origin in craving, its cessation, and the path.",
      "The Eightfold Path: right view, intention, speech, action, livelihood, effort, mindfulness, concentration.",
      "Anatta: no permanent, independent self.",
      "Impermanence (anicca): all conditioned things pass; clinging brings suffering.",
    ],
    works: ["Discourses preserved in the Pali Canon (Sutta Pitaka)"],
    quotes: [
      {
        text: "Holding on to anger is like grasping a hot coal with the intent of throwing it at someone else; you are the one who gets burned.",
        source: "Commonly misattributed to the Buddha; not found in canonical Pali texts. Use with caution.",
        kind: "paraphrase",
      },
      {
        text: "The mind is everything. What you think you become.",
        source: "Dhammapada 1-2 (paraphrase of verses beginning 'All things are preceded by the mind')",
        kind: "public-domain",
      },
      {
        text: "Hatred is never appeased by hatred in this world. By non-hatred alone is hatred appeased. This is an eternal law.",
        source: "Dhammapada 5 (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "nagarjuna",
    name: "Nagarjuna",
    tradition: "Buddhist",
    era: "Classical",
    years: "c. 150–250 CE",
    region: "India",
    school: "Madhyamaka",
    essence: "All things are empty of inherent existence; emptiness itself is empty.",
    summary:
      "Founder of the Madhyamaka (Middle Way) school, Nagarjuna deployed relentless logic to show that all phenomena, including Buddhist doctrines, are dependently co-arisen and therefore 'empty' (shunya) of independent essence. To realize emptiness is not nihilism but freedom from reified views.",
    keyIdeas: [
      "Shunyata (emptiness): things lack intrinsic nature because they depend on causes and conditions.",
      "Two truths: conventional truth (the world of appearances) and ultimate truth (emptiness).",
      "Pratitya-samutpada: dependent co-arising as the heart of the Middle Way.",
      "The tetralemma: a thing neither is, nor is not, nor both, nor neither — beyond the four corners of logic.",
    ],
    works: ["Mulamadhyamakakarika (Fundamental Verses on the Middle Way)"],
    quotes: [
      {
        text: "For whom emptiness is possible, everything is possible. For whom emptiness is impossible, nothing is possible.",
        source: "MMK 24.14 (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "adi-shankara",
    name: "Adi Shankara",
    tradition: "Indian",
    era: "Medieval",
    years: "c. 700–750 CE",
    region: "Kerala, India",
    school: "Advaita Vedanta",
    essence: "Brahman alone is real; the world is appearance; the self is Brahman.",
    summary:
      "The foremost exponent of Advaita (non-dual) Vedanta, Shankara consolidated a reading of the Upanishads in which the individual self (atman) is identical with the ultimate reality (Brahman). The empirical world is maya — not illusion but misperception born of ignorance.",
    keyIdeas: [
      "Brahman is sat-chit-ananda: being, consciousness, bliss, without second.",
      "Atman = Brahman: the deepest self is not personal but universal.",
      "Maya: the cosmic power that makes the One appear as many.",
      "Jivanmukti: liberation while still embodied, through direct knowledge.",
    ],
    works: ["Commentaries on the Upanishads, Brahma Sutras, Bhagavad Gita", "Vivekachudamani"],
    quotes: [
      {
        text: "Brahman is the only truth, the world is illusion, and there is ultimately no difference between Brahman and the individual self.",
        source: "Traditional Advaita formula (paraphrase)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "ramanuja",
    name: "Ramanuja",
    tradition: "Indian",
    era: "Medieval",
    years: "c. 1017–1137 CE",
    region: "Tamil Nadu, India",
    school: "Vishishtadvaita",
    essence: "The soul and the world are the body of God — qualified non-dualism.",
    summary:
      "Chief acharya of the Sri Vaishnava tradition, Ramanuja argued against Shankara's strict non-dualism. The world and individual souls are real, but they exist as the 'body' of Brahman (God, identified with Vishnu/Narayana), inseparable from yet distinct from him.",
    keyIdeas: [
      "Vishishtadvaita: non-dualism of the qualified whole — God with his modes.",
      "Prapatti: complete self-surrender as the path to liberation.",
      "Bhakti: loving devotion as superior to bare knowledge.",
      "The body-soul analogy extended to the cosmos: world and souls are God's body.",
    ],
    works: ["Sri Bhashya", "Gita Bhashya", "Vedartha Sangraha"],
    quotes: [],
  },

  // ============================================================
  // ISLAMIC & JEWISH MEDIEVAL
  // ============================================================
  {
    id: "avicenna",
    name: "Avicenna (Ibn Sina)",
    tradition: "Islamic",
    era: "Medieval",
    years: "980–1037 CE",
    region: "Persia (Bukhara, Isfahan)",
    school: "Avicennism",
    essence: "Being is divided into necessary and possible; the First Cause is pure existence.",
    summary:
      "Physician, polymath, and the most influential philosopher of the Islamic Golden Age. Avicenna synthesized Aristotelianism with Neoplatonism, arguing that the world is eternally emanated from a Necessary Existent. His 'flying man' thought experiment anticipates modern arguments for self-awareness.",
    keyIdeas: [
      "Necessary vs. possible existence: only God exists necessarily; all else is contingent.",
      "The flying man: suspended in void without sensation, one still knows one's own existence.",
      "Emanation: the cosmos flows necessarily from the One through a series of intellects.",
      "Distinction between essence and existence — existence is an 'accident' of essence.",
    ],
    works: ["The Book of Healing (Kitab al-Shifa)", "The Canon of Medicine"],
    quotes: [],
  },
  {
    id: "al-ghazali",
    name: "Al-Ghazali",
    tradition: "Islamic",
    era: "Medieval",
    years: "c. 1058–1111 CE",
    region: "Tus, Persia",
    school: "Ash'ari theology / Sufism",
    essence: "The Incoherence of the Philosophers — reason cannot ground itself.",
    summary:
      "A jurist, theologian, and mystic whose Deliverance from Error recounts a crisis of doubt and recovery through Sufi experience. His Incoherence attacked the Aristotelian philosophers (falasifa) for holding doctrines incompatible with divine omnipotence, especially the eternity of the world.",
    keyIdeas: [
      "Occasionalism: God directly causes every event; 'natural causes' are merely God's habitual occasions.",
      "Skepticism toward unaided reason; certainty is possible only through divine illumination.",
      "The limits of philosophy: falasifa were guilty of unbelief on three points.",
      "Inner Sufi experience as the path to certain knowledge.",
    ],
    works: ["The Incoherence of the Philosophers", "The Revival of the Religious Sciences", "Deliverance from Error"],
    quotes: [],
  },
  {
    id: "averroes",
    name: "Averroes (Ibn Rushd)",
    tradition: "Islamic",
    era: "Medieval",
    years: "1126–1198 CE",
    region: "Andalusia (Cordoba)",
    school: "Averroism",
    essence: "Aristotle's philosophy and revelation are twin truths; they cannot conflict.",
    summary:
      "Known to Latin Europe simply as 'the Commentator,' Averroes wrote the most rigorous medieval defenses of Aristotle. He argued that philosophy and scripture teach the same truths in different registers, and that the literal meaning of scripture may be reinterpreted when demonstrative reason requires.",
    keyIdeas: [
      "The doctrine of twofold truth: philosophical demonstration and revelation agree at bottom.",
      "Three classes of minds: demonstrative (philosophers), dialectical (theologians), rhetorical (the masses).",
      "The unity of the intellect: one shared active intellect for all humans.",
      "Eternity of the world against creation in time.",
    ],
    works: ["The Incoherence of the Incoherence", "Long Commentaries on Aristotle"],
    quotes: [],
  },
  {
    id: "rumi",
    name: "Rumi (Jalal al-Din)",
    tradition: "Islamic",
    era: "Medieval",
    years: "1207–1273 CE",
    region: "Balkh / Konya",
    school: "Sufi mysticism",
    essence: "Lover, beloved, and love are one — beyond all forms and creeds.",
    summary:
      "Persian Sufi mystic and poet whose Masnavi is sometimes called 'the Quran in Persian.' Rumi's poetry dissolves the boundaries between lover and beloved, self and God, reason and ecstasy. To avoid reproducing copyrighted modern translations, the lines below are from public-domain 19th-century renderings or paraphrases of his themes.",
    keyIdeas: [
      "Fana and baqa: annihilation of the ego in God, then subsistence in God.",
      "Ishq: a love that transfigures the lover, dissolving ego boundaries.",
      "The reed flute's lament — the soul's longing for its source.",
      "Many religions, one path: the lamp differs, the Light is one.",
    ],
    works: ["Masnavi", "Divan-e Shams-e Tabrizi", "Fihi Ma Fihi"],
    quotes: [
      {
        text: "Come, come, whoever you are. Wanderer, worshiper, lover of leaving. It doesn't matter. Ours is not a caravan of despair.",
        source: "Attr. Rumi (public-domain paraphrase; the original is from the Rubaiyat)",
        kind: "paraphrase",
      },
      {
        text: "Let the beauty of what you love be what you do.",
        source: "Attr. Rumi (paraphrase; original theme from Masnavi)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "maimonides",
    name: "Maimonides",
    tradition: "Jewish",
    era: "Medieval",
    years: "1138–1204 CE",
    region: "Cordoba / Cairo",
    school: "Jewish philosophy",
    essence: "Negative theology: we say what God is not, never what God is.",
    summary:
      "Rabbi, physician, and philosopher whose Guide for the Perplexed attempted to reconcile Aristotelian philosophy with Torah. He argued that positive attributes of God are metaphorical; we can only meaningfully describe what God is not. He also formulated the famous thirteen principles of Jewish faith.",
    keyIdeas: [
      "Via negativa: God can be described only by negations.",
      "Prophecy as the perfection of the rational faculty.",
      "The world is created ex nihilo against the Aristotelian eternity thesis.",
      "Philosophy as a handmaiden to revelation, but never its judge.",
    ],
    works: ["The Guide for the Perplexed", "Mishneh Torah"],
    quotes: [],
  },

  // ============================================================
  // WESTERN MEDIEVAL & EARLY MODERN
  // ============================================================
  {
    id: "augustine",
    name: "Augustine of Hippo",
    tradition: "Western",
    era: "Medieval",
    years: "354–430 CE",
    region: "Roman North Africa",
    school: "Patristic / Christian Platonism",
    essence: "Our hearts are restless until they rest in God.",
    summary:
      "Bishop of Hippo whose Confessions — the first spiritual autobiography — recounts his restless search through Manichaeism, skepticism, and Neoplatonism to Christian faith. He shaped Western theology with doctrines of original sin, divine grace, and the inner life as the locus of truth.",
    keyIdeas: [
      "Restlessness of the heart: only God can satisfy human longing.",
      "Original sin and inherited guilt from Adam's fall.",
      "Necessity of grace: the will is wounded and cannot heal itself.",
      "Time as distentio animi — the mind's stretching across memory, attention, and expectation.",
    ],
    works: ["Confessions", "City of God", "On the Trinity"],
    quotes: [
      {
        text: "You have made us for yourself, O Lord, and our heart is restless until it rests in you.",
        source: "Confessions, Book I (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "aquinas",
    name: "Thomas Aquinas",
    tradition: "Western",
    era: "Medieval",
    years: "1225–1274 CE",
    region: "Roccasecca / Paris",
    school: "Scholasticism",
    essence: "Grace perfects nature; faith and reason both come from God.",
    summary:
      "Dominican friar whose Summa Theologiae systematized Christian theology by drawing on Aristotle, whom he called 'the Philosopher.' He argued that reason can demonstrate God's existence through five ways, and that faith and reason, since both originate in God, cannot finally contradict.",
    keyIdeas: [
      "The Five Ways: arguments from motion, causation, contingency, degree, and design.",
      "Analogy of being (analogia entis): predicates applied to God and creatures analogically, not univocally.",
      "Natural law: moral precepts accessible to reason, grounded in human nature.",
      "The four cardinal and three theological virtues as the structure of the moral life.",
    ],
    works: ["Summa Theologiae", "Summa contra Gentiles", "Disputed Questions on Truth"],
    quotes: [],
  },
  {
    id: "machiavelli",
    name: "Niccolò Machiavelli",
    tradition: "Western",
    era: "Early Modern",
    years: "1469–1527 CE",
    region: "Florence",
    school: "Political realism",
    essence: "In politics, one must learn how not to be good.",
    summary:
      "Florentine diplomat whose The Prince detached political analysis from Christian moralizing. He argued that effective rulers must be willing to use deceit, cruelty, and fear when circumstances require — not from vice, but from a clear-eyed acceptance of how power actually works.",
    keyIdeas: [
      "Virtù: not Christian virtue but the manly skill to bend fortune to one's will.",
      "Fortuna as a river that can be channeled but not abolished.",
      "The lion and the fox: a ruler must combine force with cunning.",
      "It is safer to be feared than loved, if one cannot be both.",
    ],
    works: ["The Prince", "Discourses on Livy"],
    quotes: [
      {
        text: "It is much safer to be feared than loved because love is preserved by the link of obligation which, owing to the baseness of men, is broken at every opportunity for their advantage; but fear preserves you by a dread of punishment which never fails.",
        source: "The Prince, Chapter 17 (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "montaigne",
    name: "Michel de Montaigne",
    tradition: "Western",
    era: "Early Modern",
    years: "1533–1592 CE",
    region: "Périgord, France",
    school: "Skeptical humanism",
    essence: "What do I know? — the only honest motto.",
    summary:
      "Inventor of the essay as a literary form, Montaigne retired to his tower to interrogate himself across every domain of human life. His insistent question 'Que sais-je?' (What do I know?) became a watchword of moderate skepticism: hold beliefs loosely, observe customs charitably, study yourself.",
    keyIdeas: [
      "Pyrrhonian skepticism: suspend judgment, follow customs, inquire without end.",
      "Self-study as the only serious subject — 'I am the matter of my book.'",
      "Cultural relativism: customs vary; nothing is universally natural to man except variety.",
      "Philosophy as the art of dying well — and so of living well.",
    ],
    works: ["Essais"],
    quotes: [
      {
        text: "The greatest thing in the world is to know how to belong to oneself.",
        source: "Essays (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "descartes",
    name: "René Descartes",
    tradition: "Western",
    era: "Early Modern",
    years: "1596–1650 CE",
    region: "France / Netherlands",
    school: "Rationalism",
    essence: "I think, therefore I am — the bedrock certainty.",
    summary:
      "Father of modern philosophy, Descartes sought to rebuild knowledge on indubitable foundations. By methodically doubting everything that could possibly be doubted, he arrived at the certainty of his own thinking existence, then argued for God's existence and the reliability of clear and distinct ideas.",
    keyIdeas: [
      "Methodic doubt: suspend belief in anything that could conceivably be false.",
      "Cogito ergo sum: the indubitable certainty of the thinking self.",
      "Mind-body dualism: res cogitans (thinking thing) vs. res extensa (extended thing).",
      "Innate ideas: concepts placed in the mind by God, available to pure reason.",
    ],
    works: ["Meditations on First Philosophy", "Discourse on the Method", "Principles of Philosophy"],
    quotes: [
      {
        text: "I think, therefore I am.",
        source: "Discourse on the Method (public-domain translation of cogito ergo sum)",
        kind: "public-domain",
      },
      {
        text: "It is not enough to have a good mind; the main thing is to use it well.",
        source: "Discourse on the Method (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "spinoza",
    name: "Baruch Spinoza",
    tradition: "Western",
    era: "Early Modern",
    years: "1632–1677 CE",
    region: "Amsterdam",
    school: "Rationalist pantheism",
    essence: "God or Nature — there is one substance, and we are its modes.",
    summary:
      "Lens-grinder by trade, excommunicated from the Amsterdam synagogue at 23, Spinoza argued in geometrical order that there is only one substance, which is both God and Nature (Deus sive Natura). The emotions are not to be suppressed but understood; freedom lies in rational necessity gladly accepted.",
    keyIdeas: [
      "Substance monism: only God/Nature exists truly; all finite things are modes of it.",
      "Determinism: nothing could have been otherwise; things could not have been produced in any other order.",
      "Conatus: each thing strives to persist in its being — the basis of emotion.",
      "The intellectual love of God: the highest blessedness, an intuition of necessity.",
    ],
    works: ["Ethics", "Tractatus Theologico-Politicus"],
    quotes: [
      {
        text: "I have striven not to laugh at human actions, not to weep at them, nor to hate them, but to understand them.",
        source: "Tractatus Politicus (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Peace is not an absence of war, it is a virtue, a state of mind, a disposition for benevolence, confidence, justice.",
        source: "Political Treatise (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "locke",
    name: "John Locke",
    tradition: "Western",
    era: "Early Modern",
    years: "1632–1704 CE",
    region: "England",
    school: "British Empiricism",
    essence: "The mind at birth is a blank slate; all ideas come from experience.",
    summary:
      "Physician, civil servant, and political theorist. Locke argued that there are no innate ideas — the mind begins as white paper, filled by sensation and reflection. In politics, he defended natural rights to life, liberty, and property, and the right to revolt against tyrannical government.",
    keyIdeas: [
      "Tabula rasa: the mind as blank slate written on by experience.",
      "Primary vs. secondary qualities: properties in things vs. powers to produce sensations in us.",
      "Natural rights: life, liberty, and property, antecedent to civil society.",
      "Consent of the governed as the sole legitimate basis of political authority.",
    ],
    works: ["Essay Concerning Human Understanding", "Two Treatises of Government"],
    quotes: [
      {
        text: "The actions of men are the best interpreters of their thoughts.",
        source: "Essay Concerning Human Understanding (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "hume",
    name: "David Hume",
    tradition: "Western",
    era: "Early Modern",
    years: "1711–1776 CE",
    region: "Scotland",
    school: "British Empiricism",
    essence: "Reason is, and ought only to be, the slave of the passions.",
    summary:
      "Scottish philosopher and historian whose radical empiricism pushed Lockean principles to their skeptical conclusions. Hume argued that causation is not perceived but habitually inferred, that induction has no rational justification, and that morality rests on sentiment rather than reason.",
    keyIdeas: [
      "The problem of induction: past regularities give no rational guarantee about the future.",
      "Causation as constant conjunction plus the mind's habit of expectation.",
      "The is-ought gap: no purely descriptive premise can yield a normative conclusion.",
      "Bundle theory of the self: there is no impression of a unified self, only a bundle of perceptions.",
    ],
    works: ["A Treatise of Human Nature", "An Enquiry Concerning Human Understanding", "Dialogues Concerning Natural Religion"],
    quotes: [
      {
        text: "Reason is, and ought only to be the slave of the passions, and can never pretend to any other office than to serve and obey them.",
        source: "A Treatise of Human Nature, Book II (public-domain)",
        kind: "public-domain",
      },
      {
        text: "Beauty is no quality in things themselves: it exists merely in the mind which contemplates them.",
        source: "Of the Standard of Taste (public-domain)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "kant",
    name: "Immanuel Kant",
    tradition: "Western",
    era: "Early Modern",
    years: "1724–1804 CE",
    region: "Königsberg, Prussia",
    school: "Critical philosophy",
    essence: "The mind does not conform to objects; objects conform to the mind.",
    summary:
      "Kant's three Critiques sought to determine the limits and powers of human reason. The mind, he argued, actively structures experience through a priori forms of intuition (space, time) and categories (cause, substance). In ethics, he grounded morality in the categorical imperative — act only on a maxim you could will to be universal law.",
    keyIdeas: [
      "Copernican revolution in philosophy: objects conform to the mind's structuring activity, not vice versa.",
      "Phenomena vs. noumena: things as they appear to us vs. things in themselves.",
      "Categorical imperative: act only on maxims fit to become universal law.",
      "Treat humanity, in yourself and others, always as an end and never merely as a means.",
    ],
    works: ["Critique of Pure Reason", "Critique of Practical Reason", "Critique of Judgment"],
    quotes: [
      {
        text: "Two things fill the mind with ever new and increasing admiration and awe: the starry heavens above me and the moral law within me.",
        source: "Critique of Practical Reason (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Sapere aude! Have the courage to use your own understanding.",
        source: "What is Enlightenment? (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },

  // ============================================================
  // WESTERN MODERN (19th century)
  // ============================================================
  {
    id: "hegel",
    name: "G. W. F. Hegel",
    tradition: "Western",
    era: "Modern",
    years: "1770–1831 CE",
    region: "Stuttgart / Berlin",
    school: "German Idealism",
    essence: "The rational is real; the real is rational — history is spirit coming to know itself.",
    summary:
      "Hegel argued that reality is the self-development of Geist (Spirit/Mind) through dialectical stages. History is the progress of freedom, each epoch resolving contradictions of the last. Truth is not a static proposition but the whole — the entire developmental process grasped in its necessity.",
    keyIdeas: [
      "Dialectic: thesis-antipathy-synthesis, more precisely Aufhebung — sublation that preserves and cancels.",
      "Master-slave dialectic: self-consciousness requires recognition by another self-consciousness.",
      "The owl of Minerva flies at dusk: philosophy comprehends an epoch only as it ends.",
      "History as the progress of the consciousness of freedom.",
    ],
    works: ["Phenomenology of Spirit", "Science of Logic", "Elements of the Philosophy of Right"],
    quotes: [
      {
        text: "The owl of Minerva spreads its wings only with the falling of the dusk.",
        source: "Preface, Philosophy of Right (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Nothing great in the world has ever been accomplished without passion.",
        source: "Philosophy of History (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "schopenhauer",
    name: "Arthur Schopenhauer",
    tradition: "Western",
    era: "Modern",
    years: "1788–1860 CE",
    region: "Danzig / Frankfurt",
    school: "Voluntaristic idealism",
    essence: "The world is my will — and my representation.",
    summary:
      "Drawing on Kant and the Upanishads, Schopenhauer held that the inner essence of all things is an irrational, striving Will. The phenomenal world is its representation; beneath lies endless, purposeless striving. Escape lies in aesthetic contemplation, compassion, and ascetic withdrawal.",
    keyIdeas: [
      "Will as thing-in-itself: blind, purposeless striving that underlies all phenomena.",
      "Representation (Vorstellung): the world as structured by the mind's forms.",
      "Aesthetic contemplation as momentary release from the will's demands.",
      "Compassion as the moral basis: recognizing the same will suffering in all beings.",
    ],
    works: ["The World as Will and Representation", "Parerga and Paralipomena"],
    quotes: [
      {
        text: "Talent hits a target no one else can hit; genius hits a target no one else can see.",
        source: "Parerga and Paralipomena (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "kierkegaard",
    name: "Søren Kierkegaard",
    tradition: "Western",
    era: "Modern",
    years: "1813–1855 CE",
    region: "Copenhagen",
    school: "Existentialism (proto-)",
    essence: "Subjectivity is truth — choose yourself, before God, in fear and trembling.",
    summary:
      "Danish theologian who attacked Hegel's system as a palace of abstractions that swallows the existing individual. Truth, for Kierkegaard, is not a proposition one holds but a relation one lives. The self is a task — a synthesis of finite and infinite, temporal and eternal, grounded in God.",
    keyIdeas: [
      "Three stages of existence: aesthetic, ethical, religious.",
      "Angst (dread) as the dizziness of freedom.",
      "The leap of faith: no reasoned path to the religious, only a passionate commitment.",
      "Truth is subjectivity: how one holds a belief matters more than what is held.",
    ],
    works: ["Either/Or", "Fear and Trembling", "The Sickness unto Death", "Concluding Unscientific Postscript"],
    quotes: [
      {
        text: "Life can only be understood backwards; but it must be lived forwards.",
        source: "Journals (public-domain)",
        kind: "public-domain",
      },
      {
        text: "Anxiety is the dizziness of freedom.",
        source: "The Concept of Anxiety (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "marx",
    name: "Karl Marx",
    tradition: "Western",
    era: "Modern",
    years: "1818–1883 CE",
    region: "Trier / London",
    school: "Historical materialism",
    essence: "The philosophers have only interpreted the world; the point is to change it.",
    summary:
      "With Engels, Marx developed a materialist account of history in which the economic 'base' (forces and relations of production) shapes the ideological 'superstructure' (law, religion, art). Capitalism, he argued, systematically extracts surplus value from labor and will be superseded by communism.",
    keyIdeas: [
      "Historical materialism: history is driven by class struggle over the means of production.",
      "Surplus value: the difference between the value workers produce and the wages they receive.",
      "Alienation: under capitalism, workers are estranged from their product, their labor, their species-being, and each other.",
      "Base and superstructure: economics conditions politics, law, religion, and culture.",
    ],
    works: ["Capital", "The Communist Manifesto (with Engels)", "Economic and Philosophic Manuscripts of 1844"],
    quotes: [
      {
        text: "The philosophers have only interpreted the world, in various ways; the point is to change it.",
        source: "Theses on Feuerbach, XI (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "Religion is the opium of the people.",
        source: "Contribution to the Critique of Hegel's Philosophy of Right (public-domain)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "nietzsche",
    name: "Friedrich Nietzsche",
    tradition: "Western",
    era: "Modern",
    years: "1844–1900 CE",
    region: "Röcken / Weimar",
    school: "Existentialism (proto-) / Perspectivism",
    essence: "God is dead — and we have killed him. Now we must become worthy of having done so.",
    summary:
      "Philologist-turned-philosopher who attacked the moral and metaphysical foundations of Western culture. He diagnosed the 'death of God' — the collapse of the Christian-Platonic worldview — and called for a 'revaluation of all values' in which the free spirit creates meaning without appeal to transcendent sanction.",
    keyIdeas: [
      "Will to power: the fundamental drive, not mere survival but self-overcoming expansion.",
      "Perspectivism: all knowing is interpretive, from a standpoint; there is no 'view from nowhere.'",
      "Eternal recurrence: live so that you could will your life to repeat eternally without end.",
      "Übermensch: the overman who creates values in the absence of transcendent grounding.",
    ],
    works: ["Thus Spoke Zarathustra", "Beyond Good and Evil", "On the Genealogy of Morals", "The Gay Science"],
    quotes: [
      {
        text: "He who has a why to live for can bear almost any how.",
        source: "Twilight of the Idols (public-domain translation)",
        kind: "public-domain",
      },
      {
        text: "And those who were seen dancing were thought to be insane by those who could not hear the music.",
        source: "Attr. Nietzsche (paraphrase; spirit aligns with Zarathustra)",
        kind: "paraphrase",
      },
      {
        text: "What does not kill me makes me stronger.",
        source: "The Twilight of the Idols (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },
  {
    id: "william-james",
    name: "William James",
    tradition: "Western",
    era: "Modern",
    years: "1842–1910 CE",
    region: "United States",
    school: "Pragmatism",
    essence: "Truth is what works in the long run — ideas are tools, not mirrors.",
    summary:
      "Harvard psychologist and philosopher, James argued that the meaning and truth of an idea lie in its practical consequences. A belief is true if acting on it leads us into satisfactory relations with our experience. He defended the right to believe where evidence is insufficient and the stakes are forced.",
    keyIdeas: [
      "The pragmatic maxim: trace a concept's practical effects to grasp its meaning.",
      "Radical empiricism: only what is experienceable is real; relations are experienced too.",
      "The will to believe: we may believe ahead of evidence when the choice is live, forced, and momentous.",
      "Stream of consciousness: thought is a continuous flow, not discrete ideas.",
    ],
    works: ["The Principles of Psychology", "Pragmatism", "The Varieties of Religious Experience"],
    quotes: [
      {
        text: "The greatest discovery of my generation is that a human being can alter his life by altering his attitudes of mind.",
        source: "Varieties of Religious Experience (paraphrase)",
        kind: "paraphrase",
      },
      {
        text: "Act as if what you do makes a difference. It does.",
        source: "Attr. William James (paraphrase, common attribution)",
        kind: "paraphrase",
      },
    ],
  },

  // ============================================================
  // EAST ASIAN MEDIEVAL / EARLY MODERN
  // ============================================================
  {
    id: "dogen",
    name: "Dōgen",
    tradition: "Japanese",
    era: "Medieval",
    years: "1200–1253 CE",
    region: "Japan",
    school: "Sōtō Zen",
    essence: "To study the way is to study the self; to study the self is to forget the self.",
    summary:
      "Founder of Sōtō Zen in Japan after study in China, Dōgen wrote with fierce precision about meditation (zazen) as not a means to awakening but awakening itself. His masterwork, the Shōbōgenzō ('Treasury of the True Dharma Eye'), insists that practice and enlightenment are one.",
    keyIdeas: [
      "Shikantaza: 'just sitting' — meditation without object or aim.",
      "Practice-enlightenment unity: the path is not separate from the goal.",
      "Uji (being-time): all existence is time; there is no being apart from time.",
      "Genjōkōan: the realized universe as the matter of one's own investigation.",
    ],
    works: ["Shōbōgenzō", "Eihei Kōrokū"],
    quotes: [
      {
        text: "To study the Way is to study the self. To study the self is to forget the self. To forget the self is to be enlightened by all things.",
        source: "Genjōkōan, Shōbōgenzō (public-domain translation)",
        kind: "public-domain",
      },
    ],
  },

  // ============================================================
  // CONTEMPORARY (20th century) — paraphrased only, no copyrighted wording reproduced
  // ============================================================
  {
    id: "wittgenstein",
    name: "Ludwig Wittgenstein",
    tradition: "Western",
    era: "Contemporary",
    years: "1889–1951 CE",
    region: "Vienna / Cambridge",
    school: "Analytic philosophy",
    essence: "The limits of my language mean the limits of my world.",
    summary:
      "Two phases, both transformative. The early Wittgenstein held that meaningful propositions are pictures of facts; what cannot be put into logical form — ethics, aesthetics, the meaning of life — can only be shown, not said. The later Wittgenstein dissolved this picture theory into the idea of language as many overlapping 'games' embedded in forms of life.",
    keyIdeas: [
      "Early: language pictures facts; the rest is silence (Tractatus).",
      "Later: meaning is use; words have meaning only within language-games and forms of life.",
      "Private language argument: there can be no language referring to a private inner realm.",
      "Philosophy as therapy: dissolving confusions rather than constructing theories.",
    ],
    works: ["Tractatus Logico-Philosophicus", "Philosophical Investigations (posthumous)"],
    quotes: [
      {
        text: "The limits of my language mean the limits of my world.",
        source: "Tractatus Logico-Philosophicus, 5.6 (paraphrase in our own words)",
        kind: "paraphrase",
      },
      {
        text: "Whereof one cannot speak, thereof one must be silent.",
        source: "Tractatus Logico-Philosophicus, 7 (paraphrase in our own words)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "heidegger",
    name: "Martin Heidegger",
    tradition: "Western",
    era: "Contemporary",
    years: "1889–1976 CE",
    region: "Germany",
    school: "Phenomenology / Existentialism",
    essence: "Dasein is the being for whom its own being is a question.",
    summary:
      "In Being and Time, Heidegger argued that the question of being — what it means to be at all — had been forgotten since the pre-Socratics. The human being (Dasein) is distinctive in caring about its own existence. Authentic living requires confronting one's ownmost possibility: death.",
    keyIdeas: [
      "Dasein: the being whose being is at issue for it; typically 'being-in-the-world.'",
      "Being-in-the-world: subject and object are not primordially separate; we are always already engaged.",
      "Das Man (the 'they'): inauthentic absorption in anonymous public norms.",
      "Being-toward-death: resolute anticipation of one's own finitude as the condition of authenticity.",
    ],
    works: ["Being and Time", "Contributions to Philosophy", "The Question Concerning Technology"],
    quotes: [
      {
        text: "We do not say what being is; we ask what being means.",
        source: "Paraphrase of the opening question of Being and Time",
        kind: "paraphrase",
      },
      {
        text: "To think is to confine oneself to a single thought that stands fast like a star in the world's sky.",
        source: "Paraphrase; original theme from late essays on thinking",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "sartre",
    name: "Jean-Paul Sartre",
    tradition: "Western",
    era: "Contemporary",
    years: "1905–1980 CE",
    region: "Paris",
    school: "Existentialism",
    essence: "Existence precedes essence — we are condemned to be free.",
    summary:
      "Sartre held that humans have no fixed nature; we are what we make of ourselves through choices and actions. This radical freedom produces anguish, since we cannot evade responsibility by appeal to a given essence or moral law. Bad faith is the lie we tell to deny that freedom.",
    keyIdeas: [
      "Existence precedes essence: we exist first, then define ourselves through choice.",
      "Radical freedom and responsibility: 'not to choose is still to choose.'",
      "Bad faith (mauvaise foi): pretending one is a thing with a fixed nature to evade freedom.",
      "The Look (le regard): being seen by another reveals us as objects in their world.",
    ],
    works: ["Being and Nothingness", "Existentialism is a Humanism", "Critique of Dialectical Reason"],
    quotes: [
      {
        text: "Man is condemned to be free; because once thrown into the world, he is responsible for everything he does.",
        source: "Paraphrase from Existentialism is a Humanism (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
      {
        text: "Hell is other people.",
        source: "Paraphrase from the play No Exit (Garcin's line; not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "camus",
    name: "Albert Camus",
    tradition: "Western",
    era: "Contemporary",
    years: "1913–1960 CE",
    region: "Algeria / Paris",
    school: "Absurdism",
    essence: "One must imagine Sisyphus happy.",
    summary:
      "Camus rejected the label 'existentialist' because he refused to leap from the absurd to either faith or nihilism. The absurd arises from the collision between humanity's demand for meaning and the universe's silence. The proper response is lucid revolt: to live fully in the face of that silence.",
    keyIdeas: [
      "The absurd: not in the world alone or in man alone, but in their confrontation.",
      "Revolt, freedom, and passion as the three consequences of lucid acceptance.",
      "The myth of Sisyphus: pushing the rock is itself enough to fill a human heart.",
      "Resistance to metaphysical and political suicide — neither leap of faith nor murder.",
    ],
    works: ["The Myth of Sisyphus", "The Stranger", "The Plague", "The Rebel"],
    quotes: [
      {
        text: "One must imagine Sisyphus happy.",
        source: "Paraphrase of the closing line of The Myth of Sisyphus (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
      {
        text: "In the depth of winter, I finally learned that within me there lay an invincible summer.",
        source: "Paraphrase from Return to Tipasa (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "beauvoir",
    name: "Simone de Beauvoir",
    tradition: "Western",
    era: "Contemporary",
    years: "1908–1986 CE",
    region: "Paris",
    school: "Existentialist feminism",
    essence: "One is not born, but rather becomes, a woman.",
    summary:
      "Beauvoir extended existentialist categories to gender, arguing that women have been constituted as 'the Other' — the inessential against which men define themselves as essential. Liberation requires collective political action and the reciprocal recognition of freedoms, not merely individual choice.",
    keyIdeas: [
      "The Second Sex: woman as 'the Other' constructed by male subjectivity.",
      "Immanence vs. transcendence: oppression traps women in repetitive immanence.",
      "Situation and freedom: freedom is real but always situated within material and social conditions.",
      "Reciprocal recognition: genuine freedom requires the freedom of others.",
    ],
    works: ["The Second Sex", "The Ethics of Ambiguity", "The Mandarins"],
    quotes: [
      {
        text: "One is not born, but rather becomes, a woman.",
        source: "Paraphrase of the opening of Book II of The Second Sex (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
      {
        text: "To catch a husband is an art; to hold him is a job.",
        source: "Paraphrase from The Second Sex (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "arendt",
    name: "Hannah Arendt",
    tradition: "Western",
    era: "Contemporary",
    years: "1906–1975 CE",
    region: "Germany / United States",
    school: "Political philosophy",
    essence: "The banality of evil — thoughtlessness is more dangerous than malice.",
    summary:
      "A student of Heidegger and Jaspers, Arendt drew on Greek categories to analyze modern politics. She distinguished labor, work, and action; located freedom in public political action among equals; and argued that totalitarianism rests not on monstrousness but on the collapse of judgment and the habit of thinking.",
    keyIdeas: [
      "Vita activa: labor (biological reproduction), work (world-building), action (political plurality).",
      "The banality of evil: evil done not from ideology but from thoughtless conformity.",
      "Plurality: politics requires the presence of distinct others, not unanimous masses.",
      "Natality: each birth brings the possibility of something genuinely new.",
    ],
    works: ["The Origins of Totalitarianism", "The Human Condition", "Eichmann in Jerusalem"],
    quotes: [
      {
        text: "The sad truth is that most evil is done by people who never make up their minds to be good or evil.",
        source: "Paraphrase from The Life of the Mind (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "foucault",
    name: "Michel Foucault",
    tradition: "Western",
    era: "Contemporary",
    years: "1926–1984 CE",
    region: "France",
    school: "Post-structuralism",
    essence: "Power is not held; it is exercised — through discourse, institutions, and bodies.",
    summary:
      "Foucault analyzed how institutions — prisons, asylums, clinics — produce the categories (madness, criminality, sexuality) they claim merely to describe. Power, on his view, is not repressive but productive: it shapes subjects, discourses, and pleasures. Knowledge and power are inseparable.",
    keyIdeas: [
      "Power-knowledge: forms of knowledge authorize forms of power, and vice versa.",
      "Disciplinary power: surveillance, examination, normalization (the Panopticon as model).",
      "Biopower: modern power regulates populations through birth, health, mortality.",
      "Genealogy: history not as progress but as contingent emergence from struggles.",
    ],
    works: ["Discipline and Punish", "The History of Sexuality", "Madness and Civilization"],
    quotes: [
      {
        text: "Where there is power, there is resistance.",
        source: "Paraphrase from The History of Sexuality, Vol. 1 (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
      {
        text: "People know what they do; frequently they know why they do what they do; but what they don't know is what what they do does.",
        source: "Paraphrase from a 1972 lecture (not reproduced from copyrighted translation)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "rawls",
    name: "John Rawls",
    tradition: "Western",
    era: "Contemporary",
    years: "1921–2002 CE",
    region: "United States",
    school: "Liberal political philosophy",
    essence: "Justice is fairness — what free and equal persons would choose behind a veil of ignorance.",
    summary:
      "Rawls revived systematic political philosophy with a thought experiment: design the basic structure of society from behind a 'veil of ignorance' about your future place in it. Rational parties would choose equal basic liberties and the difference principle — inequalities only insofar as they benefit the worst-off.",
    keyIdeas: [
      "Original position and veil of ignorance as devices of representation.",
      "The two principles of justice: equal basic liberties, then fair equality of opportunity + difference principle.",
      "Public reason: political justification must appeal to reasons all reasonable citizens can accept.",
      "Reflective equilibrium: adjusting principles and considered judgments until they cohere.",
    ],
    works: ["A Theory of Justice", "Political Liberalism", "The Law of Peoples"],
    quotes: [
      {
        text: "Justice is the first virtue of social institutions, as truth is of systems of thought.",
        source: "Paraphrase of the opening of A Theory of Justice (not reproduced from copyrighted text)",
        kind: "paraphrase",
      },
    ],
  },

  // ============================================================
  // INDIGENOUS, AFRICAN, LATIN AMERICAN
  // ============================================================
  {
    id: "ubuntu",
    name: "Ubuntu Philosophy (Southern African)",
    tradition: "African",
    era: "Classical",
    years: "Pre-colonial, ongoing",
    region: "Southern Africa",
    school: "Communitarian ethics",
    essence: "I am because we are; a person is a person through other persons.",
    summary:
      "Ubuntu is a Nguni word for an ethic of mutual recognition rooted in the interdependence of persons. Foundational to many Southern African moral traditions, it holds that one's humanity is realized only in relation to others — through hospitality, compassion, and shared flourishing.",
    keyIdeas: [
      "Umuntu ngumuntu ngabantu: a person is a person through other persons.",
      "Moral worth is relational, not atomistic — solitude is a moral failure.",
      "Hospitality to the stranger as a defining virtue.",
      "Restorative rather than retributive justice (cf. post-apartheid Truth and Reconciliation Commission).",
    ],
    works: ["Oral tradition; no canonical texts"],
    quotes: [
      {
        text: "I am because we are, and since we are, therefore I am.",
        source: "Translation of a Nguni proverb; common paraphrase attributed to Desmond Tutu",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "yoruba-ethics",
    name: "Yoruba Moral Philosophy",
    tradition: "African",
    era: "Classical",
    years: "Pre-colonial, ongoing",
    region: "West Africa (Nigeria, Benin)",
    school: "Character ethics",
    essence: "Iwa pe le — good character is the greatest treasure.",
    summary:
      "Yoruba moral thought centers on iwa (character) and is sustained through proverbs, myths, and the counsel of elders. Good character is measured by honesty, hospitality, courage, and the proper observance of one's relations to family, ancestors, and the orisa.",
    keyIdeas: [
      "Iwa rere: good character as the supreme human achievement.",
      "Omoluabi: a person of complete virtue — disciplined, honest, responsible.",
      "Ancestors as moral exemplars and continuing community members.",
      "Proverb as condensed moral argument (owe lesin oro).",
    ],
    works: ["Oral tradition: Ifa corpus, proverbs, oriki"],
    quotes: [
      {
        text: "Good character is the greatest treasure; wealth and beauty fade, but character endures.",
        source: "Paraphrase of a Yoruba proverb (owe)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "mayan",
    name: "Maya Wisdom Tradition",
    tradition: "Latin American",
    era: "Classical",
    years: "c. 250–900 CE (Classic Maya)",
    region: "Mesoamerica",
    school: "Indigenous cosmology",
    essence: "All is in motion; the sacred calendar measures the rhythm of the cosmos.",
    summary:
      "Classic Maya thought wove astronomy, agriculture, and ritual into a single cyclical cosmology. The 260-day Tzolkin and 365-day Haab calendars tracked sacred and mundane time; the Popol Vuh, recorded in colonial times, preserves the Quiché Maya creation narrative and reflections on the human place in the cosmos.",
    keyIdeas: [
      "Cyclical time: creation and destruction repeat across vast cosmic cycles.",
      "The sacred calendar (Tzolkin) as a map of meaning, not just a clock.",
      "In Lak'ech: 'I am another you' — a relational greeting expressing mutual sacredness.",
      "Complementarity of maize god and monkey scribe: life and story inseparable.",
    ],
    works: ["Popol Vuh (Quiché Maya)", "Dresden Codex"],
    quotes: [
      {
        text: "In Lak'ech — I am another you. Hala ken — You are another me.",
        source: "Traditional Maya greeting (paraphrase)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "navajo",
    name: "Diné (Navajo) Philosophy",
    tradition: "Indigenous",
    era: "Classical",
    years: "Pre-colonial, ongoing",
    region: "Southwest North America",
    school: "Indigenous cosmology",
    essence: "Hózhó — beauty, balance, harmony — is the goal of life.",
    summary:
      "Diné philosophy is articulated through ceremonial chants (the Blessingway, the Enemyway) and the Hogan's architecture. Hózhó names a state of dynamic balance among beauty, harmony, goodness, and right relation; its opposite, hóchxó, is disorder and dis-ease. The task of life is to walk in beauty.",
    keyIdeas: [
      "Hózhó: a rich concept uniting beauty, harmony, balance, rightness.",
      "Sa'ah naagháí bik'eh hózhóón: the lifelong circular path of male-female harmony.",
      "Diné Bahane': the emergence narrative recounting the People's journey through worlds.",
      "Ceremonial healing as restoration of hózhó, not cure of disease.",
    ],
    works: ["Oral tradition: Blessingway ceremony and chants"],
    quotes: [
      {
        text: "In beauty I walk. With beauty before me, I walk. With beauty behind me, I walk. With beauty above me, I walk. With beauty below me, I walk.",
        source: "Blessingway chant (paraphrase from public ethnographic sources)",
        kind: "paraphrase",
      },
    ],
  },
  {
    id: "australian-aboriginal",
    name: "Ab Australian Aboriginal Dreaming",
    tradition: "Indigenous",
    era: "Ancient",
    years: "60,000+ years, ongoing",
    region: "Australia",
    school: "Indigenous cosmology",
    essence: "The Dreaming is the ever-present source from which all things, including time itself, emerge.",
    summary:
      "Aboriginal Australian traditions describe a continuous sacred reality — often translated as 'the Dreaming' — in which ancestral beings shaped the land, its species, and its laws during creation and continue to do so. Time is not linear but layered: the ancestors are present now, in places and ceremonies.",
    keyIdeas: [
      "Songlines: paths sung across the land, mapping both geography and kinship.",
      "The Dreaming as ever-present origin, not a past event.",
      "Caring for Country: land and people mutually constitute one another.",
      "Law as given by the ancestors, requiring ongoing ceremony and obligation.",
    ],
    works: ["Oral tradition: song cycles, ceremonies, rock art"],
    quotes: [
      {
        text: "We do not own the land; the land owns us. The land is my mother, my mother is the land.",
        source: "Paraphrase of common Aboriginal expression",
        kind: "paraphrase",
      },
    ],
  },
];

// ============================================================
// HELPERS
// ============================================================

export const traditions: Tradition[] = [
  "Western",
  "Chinese",
  "Indian",
  "Buddhist",
  "Japanese",
  "Islamic",
  "Jewish",
  "African",
  "Indigenous",
  "Latin American",
];

export const eras: Era[] = ["Ancient", "Classical", "Medieval", "Early Modern", "Modern", "Contemporary"];

export const eraBlurb: Record<Era, string> = {
  Ancient: "c. 600 BCE – 200 BCE — the axial dawn",
  Classical: "c. 200 BCE – 500 CE — schools and empires",
  Medieval: "c. 500 – 1500 CE — faith and reason",
  "Early Modern": "c. 1500 – 1800 CE — the new science",
  Modern: "c. 1800 – 1945 — systems and revolutions",
  Contemporary: "1945 – present — language, power, freedom",
};

/** Flatten all public-domain quotes into a single deck for the carousel. */
export const allPublicDomainQuotes = philosophers.flatMap((p) =>
  p.quotes.filter((q) => q.kind === "public-domain").map((q) => ({ ...q, philosopher: p.name, school: p.school })),
);
