// Comprehensive Psychology Data

export const timelineEras = [
  {
    id: "ancient",
    era: "Ancient Roots",
    period: "c. 1550 BCE – 500 CE",
    color: "from-amber-500 to-orange-600",
    bgClass: "bg-amber-50 dark:bg-amber-950/30",
    borderClass: "border-amber-300 dark:border-amber-700",
    description:
      "The earliest inquiries into the mind and behavior emerged in ancient civilizations across Egypt, Greece, China, and India. These foundational ideas about the soul, consciousness, and mental illness set the stage for all future psychological thought. Philosophers and physicians began distinguishing between physical and mental phenomena, proposing early models of cognition, emotion, and perception that would resonate for millennia.",
    events: [
      {
        year: "c. 1550 BCE",
        title: "Ebers Papyrus",
        description:
          "One of the oldest medical documents, the Ebers Papyrus from ancient Egypt, describes mental disorders such as depression and dementia. It reflects early attempts to understand and treat psychological suffering through both natural and supernatural explanations, marking the beginning of recorded thought about mental health.",
      },
      {
        year: "c. 600 BCE",
        title: "Indian Vedantic Philosophy",
        description:
          "The Upanishads explore the nature of consciousness, the self (Atman), and its relationship to universal reality (Brahman). These texts present sophisticated analyses of perception, cognition, and the layers of awareness — including waking, dreaming, and deep sleep states — that parallel modern psychological frameworks.",
      },
      {
        year: "c. 500 BCE",
        title: "Buddhist Psychology",
        description:
          "Siddhartha Gautama (the Buddha) developed an extraordinarily detailed psychology of mind, analyzing mental phenomena into aggregates (skandhas), identifying conditioned arising (dependent origination) as the mechanism of suffering, and developing meditation practices for systematic mental training. Buddhist psychology remains influential in contemporary mindfulness-based therapies.",
      },
      {
        year: "c. 400 BCE",
        title: "Hippocrates — Brain as Organ of Mind",
        description:
          "Hippocrates challenged the prevailing Greek view that the heart was the seat of reason, arguing instead that the brain was the organ of thought, emotion, and sensation. This naturalistic perspective on mental illness — as a medical rather than supernatural problem — was revolutionary and laid the groundwork for the biological approach to psychology.",
      },
      {
        year: "c. 387 BCE",
        title: "Plato's Tripartite Soul",
        description:
          "In 'The Republic,' Plato proposed that the soul has three parts: reason (logistikon), spirit (thumoeides), and appetite (epithumetikon). This model of inner conflict and the ideal of harmony among these parts foreshadowed later theories of personality, including Freud's id, ego, and superego, and modern dual-process theories of cognition.",
      },
      {
        year: "c. 335 BCE",
        title: "Aristotle's De Anima",
        description:
          "Aristotle's 'On the Soul' represents the first systematic treatise on the nature of living beings and their capacities. He analyzed perception, imagination, memory, and intellect, proposing that the psyche is the form of the body — a position that influenced both medieval scholastic philosophy and contemporary philosophy of mind.",
      },
      {
        year: "c. 200 BCE",
        title: "Chinese Five Element Psychology",
        description:
          "Traditional Chinese medicine developed a psychological framework based on five elements (wood, fire, earth, metal, water), each associated with specific emotions, organs, and personality traits. This holistic system connected emotional states to physical health and seasonal cycles, anticipating modern psychosomatic medicine.",
      },
    ],
  },
  {
    id: "medieval",
    era: "Medieval & Islamic Golden Age",
    period: "500 – 1500 CE",
    color: "from-emerald-500 to-teal-600",
    bgClass: "bg-emerald-50 dark:bg-emerald-950/30",
    borderClass: "border-emerald-300 dark:border-emerald-700",
    description:
      "During the medieval period, psychological thought was preserved, refined, and advanced particularly within the Islamic world. Scholars translated Greek works, developed hospitals with dedicated mental health wards, and produced original theories of cognition, emotion, and therapy that were centuries ahead of European practices.",
    events: [
      {
        year: "c. 850",
        title: "Al-Kindi — First Islamic Philosopher",
        description:
          "Al-Kindi wrote extensively on the intellect and sorrow, producing 'On the Intellect' and 'On the Art of Averting Sorrows' — one of the earliest cognitive therapeutic approaches. He argued that psychological distress often arises from irrational beliefs and that philosophical reasoning could alleviate suffering, presaging cognitive therapy by over a millennium.",
      },
      {
        year: "c. 900",
        title: "Al-Farabi's Classification of Intellect",
        description:
          "Al-Farabi developed a sophisticated taxonomy of intellectual capacities, distinguishing between the practical and theoretical intellect, and proposing stages of intellectual development from potential to actual to acquired intellect. His work influenced both Islamic and later European scholastic philosophy.",
      },
      {
        year: "c. 980–1037",
        title: "Ibn Sina (Avicenna) — Mind-Body & Emotions",
        description:
          "Ibn Sina's 'The Canon of Medicine' included detailed discussions of neuropsychiatric disorders, the mind-body connection, and the influence of emotions on health. He described conditions resembling depression, anxiety, and hallucinations, and proposed that strong emotions could cause physical illness — a foundational insight for psychosomatic medicine.",
      },
      {
        year: "c. 1000",
        title: "Ibn Rushd (Averroes) — Unity of Intellect",
        description:
          "Ibn Rushd argued for the unity and separability of the active intellect, sparking centuries of debate in both Islamic and Christian philosophy. His commentaries on Aristotle became central to medieval European university education, influencing Thomas Aquinas and the Scholastic tradition.",
      },
      {
        year: "c. 1200",
        title: "Mamluk & Ottoman Mental Hospitals",
        description:
          "Islamic civilizations established some of the world's first dedicated mental health facilities, including the famous Maristan of Cairo. These hospitals employed music therapy, occupational therapy, and humane treatment approaches that stood in stark contrast to the punitive measures common in medieval Europe.",
      },
    ],
  },
  {
    id: "renaissance",
    era: "Renaissance & Enlightenment",
    period: "1500 – 1800",
    color: "from-rose-500 to-pink-600",
    bgClass: "bg-rose-50 dark:bg-rose-950/30",
    borderClass: "border-rose-300 dark:border-rose-700",
    description:
      "The Renaissance revived classical learning and challenged religious dogma about the mind. The Scientific Revolution introduced empirical methods, while Enlightenment philosophers debated the nature of knowledge, free will, and the relationship between mind and body with unprecedented rigor. These centuries transformed psychology from philosophical speculation toward systematic inquiry.",
    events: [
      {
        year: "1590",
        title: "Rudolph Goeckel Coins 'Psychology'",
        description:
          "German philosopher Rudolph Goeckel (Goclenius) published 'Psychologia hoc est de Hominis Perfectione,' among the first works to use the term 'psychology' in its title. This marked the formal naming of the discipline and signaled its emergence as a distinct field of study separate from general philosophy and theology.",
      },
      {
        year: "1637",
        title: "Descartes — Mind-Body Dualism",
        description:
          "In 'Meditations on First Philosophy,' Rene Descartes proposed that mind and body are fundamentally different substances — res cogitans (thinking substance) and res extensa (extended substance). This dualism dominated Western philosophy for centuries and continues to shape debates about consciousness, free will, and the hard problem of subjective experience.",
      },
      {
        year: "1690",
        title: "John Locke — Tabula Rasa",
        description:
          "Locke's 'Essay Concerning Human Understanding' argued that the mind begins as a blank slate (tabula rasa) and that all knowledge comes from experience. This empiricist position directly opposed rationalist claims of innate ideas and became a foundational principle for behaviorist and learning theories in later psychology.",
      },
      {
        year: "1748",
        title: "La Mettrie — Machine Man",
        description:
          "Julien Offray de La Mettrie's 'L'Homme Machine' (Man a Machine) argued that humans are purely physical mechanisms, extending Descartes' mechanistic view of the body to include the mind. This radical materialist position anticipated neuroscience and continues to influence debates about reductionism in psychology.",
      },
      {
        year: "1781",
        title: "Kant — Categories of Understanding",
        description:
          "Immanuel Kant's 'Critique of Pure Reason' proposed that the mind imposes categories (such as causality, substance, and unity) on raw sensory experience, making knowledge a collaboration between the world and the mind. This transcendental idealism influenced cognitive psychology's view of the mind as an active processor rather than a passive receiver.",
      },
    ],
  },
  {
    id: "birth",
    era: "Birth of Scientific Psychology",
    period: "1800 – 1900",
    color: "from-violet-500 to-purple-600",
    bgClass: "bg-violet-50 dark:bg-violet-950/30",
    borderClass: "border-violet-300 dark:border-violet-700",
    description:
      "The 19th century witnessed psychology's transformation from a branch of philosophy into an experimental science. Breakthroughs in physiology, neuroanatomy, and psychophysics provided the tools and concepts needed to study mental processes systematically. The first psychology laboratories were established, and debates between structuralism and functionalism defined the new discipline's identity.",
    events: [
      {
        year: "1808",
        title: "Gall's Phrenology",
        description:
          "Franz Joseph Gall proposed phrenology, the theory that mental faculties are localized in specific brain areas and that skull shape reveals personality. Though scientifically flawed, phrenology was historically significant in promoting the ideas of brain localization and individual differences — both central to modern neuroscience and differential psychology.",
      },
      {
        year: "1860",
        title: "Fechner's Psychophysics",
        description:
          "Gustav Fechner published 'Elements of Psychophysics,' establishing methods for measuring the relationship between physical stimuli and subjective sensations. His Weber-Fechner law and the methods of limits, constant stimuli, and adjustment became the quantitative foundation of experimental psychology.",
      },
      {
        year: "1869",
        title: "Galton — Individual Differences & Heredity",
        description:
          "Francis Galton's 'Hereditary Genius' launched the study of individual differences and pioneered statistical methods including correlation and regression. While his later advocacy of eugenics was deeply harmful, his methodological innovations — including mental testing, word association, and questionnaires — became essential tools in psychological research.",
      },
      {
        year: "1879",
        title: "Wundt's Leipzig Laboratory",
        description:
          "Wilhelm Wundt established the first formal psychology laboratory at the University of Leipzig, widely regarded as the founding event of modern psychology. Using introspection under controlled conditions, Wundt and his students studied reaction times, attention, sensation, and feeling, establishing psychology as an independent empirical science.",
      },
      {
        year: "1885",
        title: "Ebbinghaus — Memory & Forgetting",
        description:
          "Hermann Ebbinghaus published his groundbreaking research on memory using nonsense syllables, discovering the forgetting curve, the spacing effect, and the savings method. His self-experimental approach demonstrated that higher mental processes could be studied scientifically, and his findings remain foundational in educational psychology and cognitive science.",
      },
      {
        year: "1890",
        title: "James's Principles of Psychology",
        description:
          "William James's monumental 'Principles of Psychology' synthesized the existing science and introduced original ideas including the stream of consciousness, the James-Lange theory of emotion, and habit formation. The book became the most influential psychology text of its era and helped establish American functionalism.",
      },
      {
        year: "1892",
        title: "APA Founded",
        description:
          "The American Psychological Association was founded by G. Stanley Hall with 26 members, providing the first professional organization for psychologists. The APA would grow to become the largest psychological association in the world, shaping research standards, clinical practice, and public policy related to psychology.",
      },
    ],
  },
  {
    id: "schools",
    era: "Schools of Thought",
    period: "1900 – 1950",
    color: "from-cyan-500 to-sky-600",
    bgClass: "bg-cyan-50 dark:bg-cyan-950/30",
    borderClass: "border-cyan-300 dark:border-cyan-700",
    description:
      "The early 20th century saw the rise of competing schools of psychology, each offering a radically different vision of what psychology should study and how. From Freud's unconscious to Watson's behaviorism to Gestalt's holistic perception, these intellectual movements defined the discipline's major theoretical frameworks and methodological approaches, many of which remain influential today.",
    events: [
      {
        year: "1900",
        title: "Freud — The Interpretation of Dreams",
        description:
          "Sigmund Freud published 'The Interpretation of Dreams,' introducing psychoanalysis and the theory that dreams are the 'royal road to the unconscious.' Freud proposed that mental life is shaped by unconscious drives, childhood experiences, and defense mechanisms, fundamentally transforming Western understandings of motivation, personality, and mental illness.",
      },
      {
        year: "1905",
        title: "Binet-Simon Intelligence Scale",
        description:
          "Alfred Binet and Theodore Simon developed the first practical intelligence test to identify schoolchildren needing educational support. Unlike Galton's sensory-based tests, Binet assessed higher cognitive functions including judgment, comprehension, and reasoning, establishing the model for all subsequent intelligence testing.",
      },
      {
        year: "1912",
        title: "Gestalt Psychology Emerges",
        description:
          "Max Wertheimer, Kurt Koffka, and Wolfgang Kohler founded Gestalt psychology, arguing that perception is organized into meaningful wholes that are greater than the sum of their parts. Principles like figure-ground, proximity, similarity, and closure demonstrated that the mind actively structures experience, challenging both structuralist and behaviorist reductionism.",
      },
      {
        year: "1913",
        title: "Watson's Behaviorist Manifesto",
        description:
          "John B. Watson published 'Psychology as the Behaviorist Views It,' declaring that psychology should abandon the study of consciousness and focus exclusively on observable behavior. His famous 'Little Albert' experiment demonstrated conditioned fear, and his insistence on objectivity reshaped American psychology for decades.",
      },
      {
        year: "1920",
        title: "Watson & Rayner — Little Albert",
        description:
          "The Little Albert experiment conditioned an infant to fear a white rat by pairing it with a loud noise, demonstrating that emotional responses could be learned through classical conditioning. Though ethically problematic by modern standards, the study was pivotal in establishing behaviorism's claim that complex behaviors are acquired through experience.",
      },
      {
        year: "1927",
        title: "Heidegger's Being and Time",
        description:
          "Martin Heidegger's existential phenomenology deeply influenced later humanistic and existential psychology. His analysis of Dasein (being-in-the-world) challenged the Cartesian subject-object split and inspired psychologists like Rollo May and Ludwig Binswanger to develop approaches that addressed anxiety, authenticity, and the meaning of existence.",
      },
      {
        year: "1935",
        title: "Kohler — Insight Learning in Apes",
        description:
          "Wolfgang Kohler's studies of chimpanzees on Tenerife demonstrated that apes could solve problems through sudden insight rather than trial-and-error alone. Sultan the chimp stacked boxes to reach bananas and fitted sticks together, showing that nonhuman animals are capable of cognitive restructuring — a landmark in both comparative and Gestalt psychology.",
      },
      {
        year: "1938",
        title: "Skinner — Operant Conditioning",
        description:
          "B.F. Skinner published 'The Behavior of Organisms,' introducing operant conditioning — the principle that behavior is shaped by its consequences through reinforcement and punishment. The Skinner Box and schedules of reinforcement became foundational tools in behavioral psychology, applied extensively in education, therapy, and animal training.",
      },
      {
        year: "1942",
        title: "Rogers — Client-Centered Therapy",
        description:
          "Carl Rogers published 'Counseling and Psychotherapy,' introducing client-centered (later person-centered) therapy. Emphasizing empathy, unconditional positive regard, and congruence, Rogers challenged the directive approaches of both psychoanalysis and behaviorism, launching humanistic psychology as a 'third force' in the discipline.",
      },
      {
        year: "1949",
        title: "Hebb — The Organization of Behavior",
        description:
          "Donald Hebb proposed that 'neurons that fire together wire together' (Hebbian learning), providing a neurophysiological theory of how synaptic connections strengthen with repeated activation. His book bridged psychology and neuroscience, establishing neuropsychology as a discipline and laying the conceptual foundation for connectionist models and artificial neural networks.",
      },
    ],
  },
  {
    id: "cognitive",
    era: "Cognitive Revolution & Beyond",
    period: "1950 – 1990",
    color: "from-fuchsia-500 to-pink-600",
    bgClass: "bg-fuchsia-50 dark:bg-fuchsia-950/30",
    borderClass: "border-fuchsia-300 dark:border-fuchsia-700",
    description:
      "The cognitive revolution restored the study of mental processes to mainstream psychology, drawing on information theory, computer science, and linguistics. Simultaneously, neuroscience accelerated with new imaging technologies, social psychology expanded through influential experiments, and evolutionary psychology offered new explanations for the origins of behavior.",
    events: [
      {
        year: "1956",
        title: "Cognitive Revolution — Multiple Landmarks",
        description:
          "A remarkable convergence occurred: Miller's 'Magical Number Seven' paper on working memory capacity, Chomsky's critique of Skinner's verbal behavior, Bruner's discovery of coding strategies in thinking, and the Dartmouth Conference on artificial intelligence. Together, these works launched the cognitive revolution that returned mental processes to the center of psychology.",
      },
      {
        year: "1959",
        title: "Chomsky Reviews Skinner",
        description:
          "Noam Chomsky's devastating review of Skinner's 'Verbal Behavior' argued that language cannot be explained by reinforcement alone — children produce novel sentences they've never heard, suggesting innate linguistic structures. This critique fundamentally undermined radical behaviorism and bolstered the cognitive approach, while launching the field of cognitive linguistics.",
      },
      {
        year: "1960",
        title: "Tolman — Cognitive Maps in Rats",
        description:
          "Edward Tolman demonstrated that rats develop 'cognitive maps' of mazes rather than simply learning stimulus-response chains. Rats took novel shortcuts and detours, showing that they formed internal representations of their environment — a finding that anticipated cognitive psychology and challenged behaviorist assumptions about animal learning.",
      },
      {
        year: "1961",
        title: "Milgram — Obedience to Authority",
        description:
          "Stanley Milgram's experiments showed that ordinary people would administer apparently lethal electric shocks to a stranger when instructed by an authority figure. This shocking finding about the power of situational influences on behavior became one of the most famous — and controversial — studies in psychology's history.",
      },
      {
        year: "1963",
        title: "Bandura — Bobo Doll Experiment",
        description:
          "Albert Bandura demonstrated that children who observed an adult acting aggressively toward a Bobo doll were more likely to imitate that aggression, even without direct reinforcement. Social learning theory showed that behavior can be acquired through observation and modeling, bridging behaviorist and cognitive approaches.",
      },
      {
        year: "1967",
        title: "Neisser — Cognitive Psychology",
        description:
          "Ulric Neisser published 'Cognitive Psychology,' the first textbook to define and name the new field. He synthesized research on perception, attention, memory, and thinking under a unified framework, treating the mind as an information-processing system and establishing cognitive psychology as a major discipline.",
      },
      {
        year: "1971",
        title: "Zimbardo — Stanford Prison Experiment",
        description:
          "Philip Zimbardo's Stanford Prison Experiment assigned students roles as prisoners or guards, and the guards became increasingly abusive while prisoners became submissive and distressed. The study demonstrated the powerful influence of social roles and situational factors on behavior, though it has been extensively criticized on ethical and methodological grounds.",
      },
      {
        year: "1974",
        title: "Kahneman & Tversky — Heuristics & Biases",
        description:
          "Daniel Kahneman and Amos Tversky published their landmark research on judgment under uncertainty, identifying cognitive heuristics (availability, representativeness, anchoring) and systematic biases that deviate from rational choice. This work launched behavioral economics and eventually earned Kahneman the 2002 Nobel Prize in Economics.",
      },
      {
        year: "1976",
        title: "Dawkins — The Selfish Gene",
        description:
          "Richard Dawkins popularized the gene-centered view of evolution, introducing concepts like the 'meme' as a cultural replicator. His framework provided the conceptual foundation for evolutionary psychology, which seeks to explain human cognition and behavior as products of natural selection operating on psychological adaptations.",
      },
      {
        year: "1983",
        title: "Gardner — Multiple Intelligences",
        description:
          "Howard Gardner proposed that intelligence is not a single general ability but a set of distinct intelligences — linguistic, logical-mathematical, spatial, musical, bodily-kinesthetic, interpersonal, intrapersonal, and later naturalistic. This theory challenged psychometric traditions and profoundly influenced educational theory and practice worldwide.",
      },
    ],
  },
  {
    id: "modern",
    era: "Modern Integration & Future",
    period: "1990 – Present",
    color: "from-lime-500 to-green-600",
    bgClass: "bg-lime-50 dark:bg-lime-950/30",
    borderClass: "border-lime-300 dark:border-lime-700",
    description:
      "Contemporary psychology is characterized by integration across disciplines, technological innovation, and a growing awareness of cultural diversity. Neuroimaging, genomics, computational modeling, and big data have opened new frontiers, while replication challenges have prompted methodological reforms. Psychology increasingly addresses global mental health, cultural variation, and the ethical implications of emerging technologies.",
    events: [
      {
        year: "1990",
        title: "Decade of the Brain & fMRI Revolution",
        description:
          "The U.S. Congress designated the 1990s as the 'Decade of the Brain.' The development of functional magnetic resonance imaging (fMRI) enabled researchers to observe brain activity in real time, transforming cognitive neuroscience and allowing unprecedented insights into the neural basis of thought, emotion, and behavior.",
      },
      {
        year: "1994",
        title: "Mirror Neurons & Empathy",
        description:
          "Giacomo Rizzolatti and colleagues discovered mirror neurons in macaque monkeys — neurons that fire both when performing an action and when observing it. This finding generated enormous interest in the neural basis of empathy, imitation, and social cognition, though the extent of mirror neuron involvement in human empathy remains debated.",
      },
      {
        year: "1998",
        title: "Seligman — Positive Psychology",
        description:
          "Martin Seligman, as APA president, launched positive psychology as a scientific study of human flourishing, well-being, and character strengths. Moving beyond the disease model, positive psychology investigates gratitude, resilience, flow, meaning, and optimal functioning, though it has been criticized for cultural bias and insufficient attention to structural factors.",
      },
      {
        year: "2000",
        title: "Ekman — Universal Emotions Confirmed",
        description:
          "Paul Ekman's decades of cross-cultural research demonstrated that at least six basic emotions (happiness, sadness, fear, disgust, anger, surprise) have universal facial expressions recognized across cultures, including isolated preliterate societies. This finding supported evolutionary theories of emotion while also sparking debate about cultural variation in emotional experience.",
      },
      {
        year: "2005",
        title: "Henrich's WEIRD Critique",
        description:
          "Joseph Henrich and colleagues published their influential critique showing that behavioral science research relies overwhelmingly on WEIRD (Western, Educated, Industrialized, Rich, Democratic) populations, who are often outliers in global psychological variation. This critique catalyzed a movement toward greater cultural diversity and inclusivity in psychological research.",
      },
      {
        year: "2011",
        title: "Replication Crisis",
        description:
          "Diederik Stapel's fraud case and the failure to replicate many classic findings (including ego depletion, social priming, and power posing) triggered psychology's replication crisis. This led to major reforms including pre-registration, open data, larger samples, registered reports, and the Open Science Framework — fundamentally changing how psychological research is conducted and reported.",
      },
      {
        year: "2013",
        title: "DSM-5 Published",
        description:
          "The fifth edition of the Diagnostic and Statistical Manual of Mental Disorders introduced dimensional assessments alongside categorical diagnoses, reorganized diagnostic groups, and incorporated new research on neurodevelopmental and neurocognitive disorders. DSM-5 reflected ongoing tensions between biological and descriptive approaches to psychiatric classification.",
      },
      {
        year: "2016",
        title: "AI & Computational Psychiatry",
        description:
          "Advances in machine learning and artificial intelligence enabled new approaches to mental health diagnosis and treatment. Computational psychiatry uses mathematical models to understand psychiatric disorders, AI chatbots provide therapeutic support, and deep learning analyzes neuroimaging data, raising both promise and ethical concerns about automation in mental health care.",
      },
      {
        year: "2020",
        title: "COVID-19 & Global Mental Health",
        description:
          "The COVID-19 pandemic triggered a worldwide mental health crisis, with dramatic increases in anxiety, depression, loneliness, and substance use. Teletherapy expanded rapidly, research on resilience and coping intensified, and the pandemic exposed deep inequities in mental health care access, accelerating movements for systemic reform and digital mental health innovation.",
      },
      {
        year: "2023–Present",
        title: "Convergence & New Frontiers",
        description:
          "Psychology increasingly integrates with neuroscience, genetics, AI, and public health. Psychedelic-assisted therapy (psilocybin, MDMA) shows promise for treatment-resistant conditions. Network models challenge traditional diagnostic categories. Cultural neuroscience explores how brain and culture co-construct each other. The field grapples with AI's impact on cognition, identity, and mental health in an era of unprecedented technological change.",
      },
    ],
  },
];

export const humanPsychologyBranches = [
  {
    id: "clinical",
    name: "Clinical Psychology",
    icon: "Heart",
    color: "rose",
    description:
      "Clinical psychology is the largest subfield of psychology, focused on assessing, diagnosing, and treating mental disorders and psychological distress. Clinical psychologists work in hospitals, private practice, community mental health centers, and academic settings, using evidence-based interventions including cognitive-behavioral therapy, psychodynamic therapy, and integrative approaches.",
    keyTopics: [
      "Psychopathology & DSM diagnoses",
      "Psychotherapy & therapeutic alliance",
      "Psychological assessment & testing",
      "Evidence-based practice",
      "Trauma & PTSD treatment",
      "Personality disorders",
    ],
    keyFigures: ["Sigmund Freud", "Aaron Beck", "Carl Rogers", "Marsha Linehan", "Albert Ellis"],
  },
  {
    id: "cognitive",
    name: "Cognitive Psychology",
    icon: "Brain",
    color: "violet",
    description:
      "Cognitive psychology studies mental processes including attention, memory, perception, language, problem-solving, and decision-making. It treats the mind as an information-processing system and uses experimental methods to understand how people acquire, process, store, and use information. Cognitive psychology has deep connections to artificial intelligence, linguistics, and neuroscience.",
    keyTopics: [
      "Working memory & long-term memory",
      "Attention & selective processing",
      "Language acquisition & processing",
      "Decision-making & heuristics",
      "Problem-solving & creativity",
      "Metacognition & executive function",
    ],
    keyFigures: ["Ulric Neisser", "George Miller", "Daniel Kahneman", "Elizabeth Loftus", "Endel Tulving"],
  },
  {
    id: "developmental",
    name: "Developmental Psychology",
    icon: "Baby",
    color: "emerald",
    description:
      "Developmental psychology examines how people grow and change throughout the lifespan, from prenatal development through old age. It investigates physical, cognitive, social, and emotional development, asking how nature and nurture interact to shape human potential. Key questions include how children acquire language, how identity forms in adolescence, and how cognitive abilities change with aging.",
    keyTopics: [
      "Piaget's stages of cognitive development",
      "Attachment theory (Bowlby & Ainsworth)",
      "Vygotsky's sociocultural theory",
      "Theory of mind & false belief",
      "Aging & cognitive decline",
      "Moral development (Kohlberg & Gilligan)",
    ],
    keyFigures: ["Jean Piaget", "Lev Vygotsky", "John Bowlby", "Erik Erikson", "Lawrence Kohlberg"],
  },
  {
    id: "social",
    name: "Social Psychology",
    icon: "Users",
    color: "cyan",
    description:
      "Social psychology studies how individuals think, feel, and behave in social contexts. It examines phenomena such as conformity, obedience, prejudice, attraction, group dynamics, persuasion, and the self-concept. Social psychology has produced some of the most famous — and controversial — experiments in psychology's history, revealing powerful situational influences on behavior.",
    keyTopics: [
      "Conformity & group pressure (Asch)",
      "Obedience to authority (Milgram)",
      "Prejudice, stereotyping & discrimination",
      "Attribution theory & fundamental attribution error",
      "Cognitive dissonance (Festinger)",
      "Social identity theory (Tajfel & Turner)",
    ],
    keyFigures: ["Solomon Asch", "Stanley Milgram", "Leon Festinger", "Henri Tajfel", "Philip Zimbardo"],
  },
  {
    id: "neuro",
    name: "Neuropsychology",
    icon: "Zap",
    color: "amber",
    description:
      "Neuropsychology explores the relationship between brain structure/function and behavior. Using brain imaging, lesion studies, and electrophysiology, neuropsychologists map cognitive and emotional functions to specific neural systems. Clinical neuropsychology assesses and rehabilitates people with brain injuries, strokes, and neurodegenerative diseases.",
    keyTopics: [
      "Brain localization & lateralization",
      "Memory systems (hippocampus & beyond)",
      "Aphasia & language networks",
      "Executive function & frontal lobes",
      "Neuroplasticity & recovery",
      "Neurodegenerative diseases (Alzheimer's, Parkinson's)",
    ],
    keyFigures: ["Donald Hebb", "Brenda Milner", "Antonio Damasio", "Oliver Sacks", "Michael Gazzaniga"],
  },
  {
    id: "personality",
    name: "Personality Psychology",
    icon: "Fingerprint",
    color: "fuchsia",
    description:
      "Personality psychology studies the characteristic patterns of thoughts, feelings, and behaviors that make individuals unique. It investigates personality traits, types, motives, and the biological and environmental origins of individual differences. The Five-Factor Model (Big Five) is currently the dominant trait theory, though many alternative models and approaches exist.",
    keyTopics: [
      "Five-Factor Model (Big Five: OCEAN)",
      "Psychodynamic theories of personality",
      "Temperament & biological bases",
      "Person-situation debate",
      "Personality assessment (MMPI, Rorschach)",
      "Dark triad (narcissism, Machiavellianism, psychopathy)",
    ],
    keyFigures: ["Gordon Allport", "Raymond Cattell", "Hans Eysenck", "Walter Mischel", "Paul Costa & Robert McCrae"],
  },
  {
    id: "educational",
    name: "Educational Psychology",
    icon: "GraduationCap",
    color: "teal",
    description:
      "Educational psychology applies psychological principles to learning, teaching, and educational systems. It studies how people learn, what motivates learners, how to design effective instruction, and how to address learning difficulties. Educational psychologists work in schools, universities, and policy settings to optimize educational outcomes for all learners.",
    keyTopics: [
      "Learning theories (behaviorist, constructivist, social)",
      "Motivation (intrinsic vs. extrinsic)",
      "Intelligence & giftedness",
      "Learning disabilities & ADHD",
      "Classroom management & assessment",
      "Multicultural education & equity",
    ],
    keyFigures: ["B.F. Skinner", "Lev Vygotsky", "Benjamin Bloom", "Jerome Bruner", "Albert Bandura"],
  },
  {
    id: "health",
    name: "Health Psychology",
    icon: "Activity",
    color: "red",
    description:
      "Health psychology examines how psychological, biological, and social factors influence health and illness. It studies health behaviors, stress and coping, the psychophysiology of disease, patient-provider communication, and the psychological aspects of chronic illness management. Health psychologists develop interventions to promote healthy behaviors and improve quality of life.",
    keyTopics: [
      "Stress, coping & the HPA axis",
      "Health behavior change models",
      "Psychoneuroimmunology",
      "Chronic pain management",
      "Patient adherence & communication",
      "Lifestyle interventions (diet, exercise, smoking cessation)",
    ],
    keyFigures: ["Richard Lazarus", "Shelley Taylor", "Kelly McGonigal", "Judith Rodin", "Howard Leventhal"],
  },
  {
    id: "forensic",
    name: "Forensic Psychology",
    icon: "Scale",
    color: "slate",
    description:
      "Forensic psychology sits at the intersection of psychology and the legal system. Forensic psychologists evaluate defendants' competency to stand trial, assess risk of violence, provide expert testimony, work with victims and offenders, and contribute to criminal profiling, jury selection, and police interrogation practices. The field raises important ethical questions about the appropriate role of psychological expertise in legal proceedings.",
    keyTopics: [
      "Criminal profiling & behavioral analysis",
      "Competency & insanity evaluations",
      "Eyewitness testimony & false memory",
      "Jury decision-making",
      "Risk assessment & recidivism",
      "Victim psychology & trauma",
    ],
    keyFigures: ["Hugo Munsterberg", "Philip Zimbardo", "Elizabeth Loftus", "David Carson", "Saul Kassin"],
  },
  {
    id: "industrial",
    name: "Industrial-Organizational Psychology",
    icon: "Briefcase",
    color: "orange",
    description:
      "I-O psychology applies psychological principles to the workplace, focusing on employee selection, training, performance, motivation, leadership, and organizational culture. It combines knowledge of individual differences, group dynamics, and organizational systems to improve both employee well-being and organizational effectiveness.",
    keyTopics: [
      "Personnel selection & validation",
      "Job satisfaction & engagement",
      "Leadership theories & styles",
      "Team dynamics & collaboration",
      "Workplace motivation (equity, expectancy, goal-setting)",
      "Organizational culture & change management",
    ],
    keyFigures: ["Frederick Taylor", "Elton Mayo", "Douglas McGregor", "Frederick Herzberg", "Edwin Locke"],
  },
  {
    id: "evolutionary",
    name: "Evolutionary Psychology",
    icon: "Dna",
    color: "lime",
    description:
      "Evolutionary psychology applies the principles of natural selection to understand the design of the human mind. It proposes that many psychological mechanisms — including mating preferences, fear responses, social reasoning, and parental investment — evolved as adaptations to recurrent challenges faced by our ancestors. The field has generated provocative hypotheses and significant controversy regarding genetic determinism and cultural variation.",
    keyTopics: [
      "Sexual selection & mating strategies",
      "Parental investment theory",
      "Fear & threat detection as adaptations",
      "Cheater detection & social contract theory",
      "Kin selection & altruism",
      "Evolved vs. cultural explanations of behavior",
    ],
    keyFigures: ["Leda Cosmides", "John Tooby", "David Buss", "Steven Pinker", "Robert Trivers"],
  },
  {
    id: "positive",
    name: "Positive Psychology",
    icon: "Sun",
    color: "yellow",
    description:
      "Positive psychology, formally launched by Martin Seligman in 1998, studies the factors that enable individuals and communities to thrive. Rather than focusing solely on pathology, it investigates well-being, happiness, character strengths, flow, gratitude, resilience, and meaning. The field has influenced education, therapy, organizational management, and public policy, while also drawing criticism for cultural bias and insufficient attention to structural factors affecting well-being.",
    keyTopics: [
      "PERMA model (Seligman)",
      "Flow & optimal experience (Csikszentmihalyi)",
      "Gratitude & savoring interventions",
      "Resilience & post-traumatic growth",
      "Character strengths & virtues",
      "Mindfulness & well-being",
    ],
    keyFigures: ["Martin Seligman", "Mihaly Csikszentmihalyi", "Barbara Fredrickson", "Angela Duckworth", "Sonja Lyubomirsky"],
  },
];

export const nonhumanPsychology = [
  {
    id: "comparative",
    name: "Comparative Psychology",
    icon: "Bug",
    color: "amber",
    description:
      "Comparative psychology studies the behavior and mental processes of different species, using evolutionary theory to understand similarities and differences in cognition, emotion, and social behavior. Founded in the late 19th century by George Romanes and C. Lloyd Morgan, the field has produced foundational insights into learning, memory, communication, and problem-solving across the animal kingdom. Modern comparative psychology integrates behavioral ecology, cognitive ecology, and evolutionary biology.",
    keyTopics: [
      "Species-typical behaviors & adaptations",
      "Comparative cognition across taxa",
      "Morgan's Canon & parsimony",
      "Evolution of intelligence",
      "Behavioral ecology & foraging",
      "Phylogenetic analysis of behavior",
    ],
    examples: [
      "Clark's nutcrackers remembering thousands of cache locations",
      "Portia jumping spiders planning detours to prey",
      "Octopuses solving mazes and using tools",
      "Cichlid fish showing social learning",
    ],
  },
  {
    id: "animal-cognition",
    name: "Animal Cognition",
    icon: "Brain",
    color: "violet",
    description:
      "Animal cognition investigates the mental abilities of nonhuman animals, including perception, attention, memory, causal reasoning, and metacognition. Research has revealed cognitive capacities once thought unique to humans — including tool use, numerical competence, self-awareness, and planning — across species from corvids and primates to cephalopods and even insects. These findings challenge anthropocentric assumptions and raise profound ethical questions about animal welfare.",
    keyTopics: [
      "Tool use & manufacture",
      "Numerical competence & counting",
      "Metacognition & uncertainty monitoring",
      "Causal reasoning & folk physics",
      "Episodic-like memory",
      "Future planning & delay of gratification",
    ],
    examples: [
      "New Caledonian crows crafting hooked tools from twigs",
      "Chimpanzees using sequential planning in foraging",
      "Dolphins understanding referential pointing",
      "Bees demonstrating symbolic communication through waggle dance",
    ],
  },
  {
    id: "animal-social",
    name: "Animal Social Behavior",
    icon: "Users",
    color: "emerald",
    description:
      "Animal social behavior encompasses the study of cooperation, competition, communication, dominance hierarchies, and social learning in nonhuman species. Research spans from eusocial insects to complex mammalian societies, revealing how social pressures drive the evolution of intelligence, culture, and moral-like behaviors. The field connects ethology, behavioral ecology, and sociobiology.",
    keyTopics: [
      "Kin selection & inclusive fitness",
      "Reciprocal altruism & cooperation",
      "Dominance hierarchies & social rank",
      "Social learning & animal culture",
      "Reconciliation & conflict resolution",
      "Teaching in nonhuman animals",
    ],
    examples: [
      "Vervet monkeys using distinct alarm calls for different predators",
      "Meerkats teaching pups to handle scorpions",
      "Elephants mourning their dead",
      "Rats freeing trapped companions instead of taking food",
    ],
  },
  {
    id: "communication",
    name: "Animal Communication",
    icon: "MessageCircle",
    color: "rose",
    description:
      "Animal communication studies how nonhuman species exchange information through vocalizations, gestures, chemical signals, visual displays, and other modalities. Research ranges from the waggle dance of honeybees to the complex songs of humpback whales, and from primate gestural communication to the referential calls of prairie dogs. This field illuminates the evolutionary roots of language and the diversity of signaling systems in nature.",
    keyTopics: [
      "Honeybee waggle dance & symbolic communication",
      "Birdsong learning & dialects",
      "Primate vocalizations & gestural communication",
      "Chemical communication (pheromones)",
      "Seismic & electrical signaling",
      "Honest signaling vs. deception",
    ],
    examples: [
      "Prairie dogs describing human clothing colors in alarm calls",
      "Humpback whale songs spreading across ocean basins",
      "Cuttlefish producing complex body pattern signals",
      "Ants using pheromone trails for cooperative foraging",
    ],
  },
  {
    id: "ethology",
    name: "Ethology",
    icon: "Bird",
    color: "cyan",
    description:
      "Ethology, the scientific study of animal behavior in natural environments, was founded by Konrad Lorenz, Niko Tinbergen, and Karl von Frisch, who shared the 1973 Nobel Prize. Ethology emphasizes instinctive behaviors, fixed action patterns, imprinting, and the adaptive significance of behavior in the wild. Tinbergen's four questions (causation, development, function, evolution) remain a foundational framework for studying any behavior in any species.",
    keyTopics: [
      "Tinbergen's four questions",
      "Fixed action patterns & sign stimuli",
      "Imprinting & critical periods",
      "Instinct vs. learning debates",
      "Behavioral adaptation & natural selection",
      "Ritualization & display evolution",
    ],
    examples: [
      "Lorenz's greylag geese imprinting on him as mother",
      "Tinbergen's stickleback fish territorial displays",
      "Von Frisch decoding the bee waggle dance",
      "Herring gull chicks pecking at red spots on bills",
    ],
  },
  {
    id: "self-awareness",
    name: "Animal Self-Awareness & Consciousness",
    icon: "Eye",
    color: "fuchsia",
    description:
      "Research on animal self-awareness investigates whether nonhuman species possess a sense of self, consciousness, or theory of mind. The mirror self-recognition test, originally developed by Gordon Gallup Jr., has been passed by great apes, dolphins, elephants, and magpies, suggesting self-awareness may be more widespread than previously assumed. The study of animal consciousness raises profound philosophical and ethical questions about the moral status of nonhuman beings.",
    keyTopics: [
      "Mirror self-recognition test (Gallup)",
      "Theory of mind in nonhuman primates",
      "Metacognition & self-knowledge",
      "Pain & suffering in animals",
      "Animal consciousness & sentience",
      "Cambridge Declaration on Consciousness (2012)",
    ],
    examples: [
      "Chimpanzees using mirrors to inspect self-applied marks",
      "Dolphins recognizing themselves and showing self-directed behavior",
      "Elephants passing the mirror test and touching marked areas",
      "Scrub jays re-caching food when observed by competitors (theory of mind)",
    ],
  },
  {
    id: "animal-welfare",
    name: "Animal Welfare & Psychology",
    icon: "Shield",
    color: "teal",
    description:
      "Animal welfare psychology applies psychological knowledge to assess and improve the well-being of animals in captivity, agriculture, research, and the wild. It develops measures of stress, enrichment strategies, and evidence-based welfare standards. The field bridges comparative psychology, veterinary science, and ethics, and has led to significant reforms in how animals are treated in laboratories, farms, zoos, and homes.",
    keyTopics: [
      "Stress assessment (cortisol, behavior, preference tests)",
      "Environmental enrichment & cognitive stimulation",
      "Stereotypic behaviors & abnormal psychology",
      "Pain recognition & management",
      "Five freedoms framework",
      "Welfare of companion, farm, and laboratory animals",
    ],
    examples: [
      "Providing puzzle feeders to reduce zoo animal stereotypies",
      "Cognitive enrichment programs for captive primates",
      "Measuring cortisol in shelter dogs to assess stress",
      "Designing welfare-friendly housing for dairy cattle",
    ],
  },
  {
    id: "insect-psych",
    name: "Insect & Invertebrate Cognition",
    icon: "Bug",
    color: "lime",
    description:
      "Research on insect and invertebrate cognition has revealed surprising cognitive sophistication in animals with tiny brains. Honeybees can learn abstract concepts, navigate complex landscapes, and even experience something resembling optimism. Octopuses display play behavior, problem-solving, and personality differences. Ants demonstrate collective intelligence through self-organizing systems. These findings challenge assumptions about the neural requirements for complex cognition.",
    keyTopics: [
      "Honeybee cognition & concept learning",
      "Octopus intelligence & distributed neural processing",
      "Ant colony collective intelligence",
      "Jumping spider predatory planning",
      "Drosophila learning & memory genetics",
      "Cephalopod consciousness",
    ],
    examples: [
      "Bees learning to distinguish 'same' vs. 'different'",
      "Octopuses opening jars from inside and escaping enclosures",
      "Portia spiders stalking prey via indirect routes",
      "Bumblebees learning to pull strings for rewards through social observation",
    ],
  },
];

export const keyFigures = [
  {
    name: "Wilhelm Wundt",
    years: "1832–1920",
    contribution: "Father of experimental psychology; founded the first psychology laboratory in Leipzig (1879)",
    school: "Structuralism",
    color: "violet",
  },
  {
    name: "William James",
    years: "1842–1910",
    contribution: "Founded American psychology; wrote Principles of Psychology (1890); stream of consciousness; James-Lange theory of emotion",
    school: "Functionalism",
    color: "emerald",
  },
  {
    name: "Sigmund Freud",
    years: "1856–1939",
    contribution: "Founded psychoanalysis; theories of the unconscious, defense mechanisms, psychosexual development, and dream interpretation",
    school: "Psychoanalysis",
    color: "rose",
  },
  {
    name: "Ivan Pavlov",
    years: "1849–1936",
    contribution: "Discovered classical conditioning through experiments on dogs; Nobel Prize for digestion research (1904)",
    school: "Behaviorism (precursor)",
    color: "amber",
  },
  {
    name: "John B. Watson",
    years: "1878–1958",
    contribution: "Founded behaviorism; Little Albert experiment; argued psychology should study only observable behavior",
    school: "Behaviorism",
    color: "cyan",
  },
  {
    name: "B.F. Skinner",
    years: "1904–1990",
    contribution: "Developed operant conditioning; invented the Skinner Box; schedules of reinforcement; Walden Two & Beyond Freedom and Dignity",
    school: "Radical Behaviorism",
    color: "orange",
  },
  {
    name: "Carl Rogers",
    years: "1902–1987",
    contribution: "Founded person-centered therapy; emphasized empathy, unconditional positive regard, and self-actualization",
    school: "Humanistic Psychology",
    color: "teal",
  },
  {
    name: "Jean Piaget",
    years: "1896–1980",
    contribution: "Developed stage theory of cognitive development; transformed understanding of how children think and learn",
    school: "Constructivism",
    color: "lime",
  },
  {
    name: "Albert Bandura",
    years: "1925–2021",
    contribution: "Social learning theory; Bobo doll experiment; self-efficacy; reciprocal determinism; one of the most cited psychologists ever",
    school: "Social Cognitive Theory",
    color: "fuchsia",
  },
  {
    name: "Daniel Kahneman",
    years: "1934–2024",
    contribution: "Prospect theory; heuristics and biases; two-system theory of thinking; Nobel Prize in Economics (2002)",
    school: "Behavioral Economics / Cognitive Psychology",
    color: "slate",
  },
  {
    name: "Konrad Lorenz",
    years: "1903–1989",
    contribution: "Co-founded ethology; discovered imprinting in geese; Nobel Prize (1973) with Tinbergen and von Frisch",
    school: "Ethology",
    color: "red",
  },
  {
    name: "Martin Seligman",
    years: "1942–present",
    contribution: "Learned helplessness; launched positive psychology; PERMA model of well-being; former APA president",
    school: "Positive Psychology",
    color: "yellow",
  },
];

export const modernTopics = [
  {
    title: "Neuroscience & Brain Imaging",
    description:
      "Modern neuroscience employs fMRI, EEG, MEG, PET, and optogenetics to map the living brain at unprecedented resolution. Connectomics maps the brain's complete wiring diagram, while optogenetics allows researchers to activate or silence specific neurons with light. These technologies reveal how neural circuits produce perception, thought, emotion, and action, while raising questions about neural privacy and mind reading.",
    icon: "Cpu",
  },
  {
    title: "Artificial Intelligence & Psychology",
    description:
      "AI and psychology are increasingly intertwined. Large language models test theories of language and cognition, AI chatbots deliver therapy and mental health support, and machine learning algorithms diagnose mental disorders from speech, text, and social media patterns. Meanwhile, psychologists study how AI affects human cognition, decision-making, social relationships, and identity — and the ethical implications of human-AI interaction.",
    icon: "Bot",
  },
  {
    title: "Psychedelic Renaissance",
    description:
      "After decades of prohibition, psychedelic substances including psilocybin, MDMA, ketamine, and ayahuasca are being rigorously studied as treatments for depression, PTSD, addiction, and end-of-life anxiety. Clinical trials show promising results, with psilocybin-assisted therapy producing rapid and sustained improvements in treatment-resistant depression. This research is reshaping our understanding of consciousness, neuroplasticity, and therapeutic change.",
    icon: "Sparkles",
  },
  {
    title: "Cultural & Indigenous Psychology",
    description:
      "Cultural psychology examines how cultural contexts shape psychological processes, challenging the universality of many Western psychological findings. Indigenous psychologies develop frameworks rooted in local knowledge systems — including African Ubuntu psychology, Indian yoga psychology, and Native American healing traditions. This movement addresses the historical bias toward WEIRD populations and enriches the discipline's understanding of human diversity.",
    icon: "Globe",
  },
  {
    title: "Digital Mental Health",
    description:
      "Digital technologies are transforming mental health care delivery. Smartphone apps track mood and deliver interventions, VR exposure therapy treats phobias and PTSD, teletherapy expanded dramatically during COVID-19, and digital phenotyping uses phone sensors to detect early signs of mental illness. While promising, concerns about data privacy, therapeutic quality, algorithmic bias, and equitable access must be addressed.",
    icon: "Smartphone",
  },
  {
    title: "Embodied & Extended Cognition",
    description:
      "Embodied cognition proposes that thinking depends not just on the brain but on the whole body's interactions with the environment. Extended cognition (Clark & Chalmers) goes further, arguing that cognitive processes can extend beyond the body into the environment — including tools, devices, and social systems. These frameworks challenge the traditional computational view of mind and have implications for robotics, design, and education.",
    icon: "Move",
  },
  {
    title: "Open Science & Methodological Reform",
    description:
      "Psychology's replication crisis catalyzed sweeping methodological reforms. Pre-registration of hypotheses and analyses, open data and materials sharing, registered reports, and the Many Labs replication projects have improved research transparency and reliability. Statistical reforms emphasize effect sizes, confidence intervals, and Bayesian methods over null hypothesis significance testing. These changes aim to make psychology a more self-correcting and trustworthy science.",
    icon: "FlaskConical",
  },
  {
    title: "Consciousness Studies",
    description:
      "Consciousness remains one of the deepest mysteries in science. Integrated Information Theory (Tononi), Global Workspace Theory (Dehaene), Higher-Order theories, and predictive processing (Friston) offer competing frameworks for explaining subjective experience. The 'hard problem' of why physical processes give rise to qualia remains unresolved, while research on anesthesia, meditation, and altered states continues to illuminate the neural correlates of consciousness.",
    icon: "Lightbulb",
  },
];
