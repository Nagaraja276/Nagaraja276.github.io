import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "The World of Psychology — From Ancient Roots to Modern Frontiers",
  description:
    "A comprehensive exploration of all psychology — human and nonhuman, history and modern developments, from the earliest philosophical inquiries to cutting-edge neuroscience and AI.",
  keywords: [
    "psychology",
    "history of psychology",
    "cognitive science",
    "animal cognition",
    "neuroscience",
    "behavioral science",
    "mental health",
    "comparative psychology",
  ],
  authors: [{ name: "Psychology Archive" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
