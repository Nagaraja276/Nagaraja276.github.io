"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence, useInView, useScroll, useTransform } from "framer-motion";
import {
  Brain,
  Heart,
  Baby,
  Users,
  Zap,
  Fingerprint,
  GraduationCap,
  Activity,
  Scale,
  Briefcase,
  Dna,
  Sun,
  Bug,
  MessageCircle,
  Bird,
  Eye,
  Shield,
  BookOpen,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Search,
  Clock,
  Star,
  Cpu,
  Bot,
  Sparkles,
  Globe,
  Smartphone,
  Move,
  FlaskConical,
  Lightbulb,
  ArrowUp,
  Menu,
  X,
  History,
  PawPrint,
  User,
  Compass,
  Layers,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  timelineEras,
  humanPsychologyBranches,
  nonhumanPsychology,
  keyFigures,
  modernTopics,
} from "@/data/psychology-data";

// ─── Icon Mapper ────────────────────────────────────────────
const iconMap: Record<string, React.ElementType> = {
  Heart, Brain, Baby, Users, Zap, Fingerprint, GraduationCap, Activity, Scale,
  Briefcase, Dna, Sun, Bug, MessageCircle, Bird, Eye, Shield, BookOpen, Cpu,
  Bot, Sparkles, Globe, Smartphone, Move, FlaskConical, Lightbulb,
};

// ─── Color Helpers ──────────────────────────────────────────
const colorMap: Record<string, { bg: string; text: string; border: string; badge: string; hover: string; light: string }> = {
  rose:    { bg: "bg-rose-500",    text: "text-rose-600 dark:text-rose-400",    border: "border-rose-300 dark:border-rose-700",    badge: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",    hover: "hover:bg-rose-50 dark:hover:bg-rose-950/30",    light: "bg-rose-50 dark:bg-rose-950/20" },
  violet:  { bg: "bg-violet-500",  text: "text-violet-600 dark:text-violet-400",  border: "border-violet-300 dark:border-violet-700",  badge: "bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300",  hover: "hover:bg-violet-50 dark:hover:bg-violet-950/30",  light: "bg-violet-50 dark:bg-violet-950/20" },
  emerald: { bg: "bg-emerald-500", text: "text-emerald-600 dark:text-emerald-400", border: "border-emerald-300 dark:border-emerald-700", badge: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300", hover: "hover:bg-emerald-50 dark:hover:bg-emerald-950/30", light: "bg-emerald-50 dark:bg-emerald-950/20" },
  cyan:    { bg: "bg-cyan-500",    text: "text-cyan-600 dark:text-cyan-400",    border: "border-cyan-300 dark:border-cyan-700",    badge: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300",    hover: "hover:bg-cyan-50 dark:hover:bg-cyan-950/30",    light: "bg-cyan-50 dark:bg-cyan-950/20" },
  amber:   { bg: "bg-amber-500",   text: "text-amber-600 dark:text-amber-400",   border: "border-amber-300 dark:border-amber-700",   badge: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",   hover: "hover:bg-amber-50 dark:hover:bg-amber-950/30",   light: "bg-amber-50 dark:bg-amber-950/20" },
  fuchsia: { bg: "bg-fuchsia-500", text: "text-fuchsia-600 dark:text-fuchsia-400", border: "border-fuchsia-300 dark:border-fuchsia-700", badge: "bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/40 dark:text-fuchsia-300", hover: "hover:bg-fuchsia-50 dark:hover:bg-fuchsia-950/30", light: "bg-fuchsia-50 dark:bg-fuchsia-950/20" },
  teal:    { bg: "bg-teal-500",    text: "text-teal-600 dark:text-teal-400",    border: "border-teal-300 dark:border-teal-700",    badge: "bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300",    hover: "hover:bg-teal-50 dark:hover:bg-teal-950/30",    light: "bg-teal-50 dark:bg-teal-950/20" },
  orange:  { bg: "bg-orange-500",  text: "text-orange-600 dark:text-orange-400",  border: "border-orange-300 dark:border-orange-700",  badge: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",  hover: "hover:bg-orange-50 dark:hover:bg-orange-950/30",  light: "bg-orange-50 dark:bg-orange-950/20" },
  lime:    { bg: "bg-lime-500",    text: "text-lime-600 dark:text-lime-400",    border: "border-lime-300 dark:border-lime-700",    badge: "bg-lime-100 text-lime-700 dark:bg-lime-900/40 dark:text-lime-300",    hover: "hover:bg-lime-50 dark:hover:bg-lime-950/30",    light: "bg-lime-50 dark:bg-lime-950/20" },
  slate:   { bg: "bg-slate-500",   text: "text-slate-600 dark:text-slate-400",   border: "border-slate-300 dark:border-slate-700",   badge: "bg-slate-100 text-slate-700 dark:bg-slate-900/40 dark:text-slate-300",   hover: "hover:bg-slate-50 dark:hover:bg-slate-950/30",   light: "bg-slate-50 dark:bg-slate-950/20" },
  red:     { bg: "bg-red-500",     text: "text-red-600 dark:text-red-400",     border: "border-red-300 dark:border-red-700",     badge: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",     hover: "hover:bg-red-50 dark:hover:bg-red-950/30",     light: "bg-red-50 dark:bg-red-950/20" },
  yellow:  { bg: "bg-yellow-500",  text: "text-yellow-600 dark:text-yellow-400",  border: "border-yellow-300 dark:border-yellow-700",  badge: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",  hover: "hover:bg-yellow-50 dark:hover:bg-yellow-950/30",  light: "bg-yellow-50 dark:bg-yellow-950/20" },
  pink:    { bg: "bg-pink-500",    text: "text-pink-600 dark:text-pink-400",    border: "border-pink-300 dark:border-pink-700",    badge: "bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300",    hover: "hover:bg-pink-50 dark:hover:bg-pink-950/30",    light: "bg-pink-50 dark:bg-pink-950/20" },
};

function getColor(name: string) {
  return colorMap[name] || colorMap.violet;
}

// ─── Section Wrapper with Animate on Scroll ────────────────
function Section({
  id,
  children,
  className = "",
}: {
  id: string;
  children: React.ReactNode;
  className?: string;
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <motion.section
      id={id}
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`py-16 md:py-24 ${className}`}
    >
      {children}
    </motion.section>
  );
}

// ─── Navigation ─────────────────────────────────────────────
function NavItem({
  href,
  label,
  icon: Icon,
  active,
  onClick,
}: {
  href: string;
  label: string;
  icon: React.ElementType;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
        active
          ? "bg-foreground/10 text-foreground"
          : "text-muted-foreground hover:text-foreground hover:bg-foreground/5"
      }`}
    >
      <Icon className="w-4 h-4" />
      <span className="hidden md:inline">{label}</span>
    </button>
  );
}

function Navigation({ activeSection }: { activeSection: string }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMobileOpen(false);
  };

  const items = [
    { href: "hero", label: "Home", icon: Brain },
    { href: "history", label: "History", icon: History },
    { href: "human", label: "Human Psych", icon: User },
    { href: "nonhuman", label: "Nonhuman Psych", icon: PawPrint },
    { href: "figures", label: "Key Figures", icon: Star },
    { href: "modern", label: "Modern Frontiers", icon: Compass },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-violet-600 dark:text-violet-400" />
            <span className="font-bold text-lg tracking-tight">PsychWorld</span>
          </div>
          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {items.map((item) => (
              <NavItem
                key={item.href}
                href={item.href}
                label={item.label}
                icon={item.icon}
                active={activeSection === item.href}
                onClick={() => scrollTo(item.href)}
              />
            ))}
          </nav>
          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-foreground/5"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>
      {/* Mobile nav */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-border/50 bg-background/95 backdrop-blur-lg"
          >
            <div className="px-4 py-3 flex flex-col gap-1">
              {items.map((item) => (
                <NavItem
                  key={item.href}
                  href={item.href}
                  label={item.label}
                  icon={item.icon}
                  active={activeSection === item.href}
                  onClick={() => scrollTo(item.href)}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

// ─── Hero Section ───────────────────────────────────────────
function HeroSection() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 600], [0, 200]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-14">
      {/* Animated background */}
      <motion.div style={{ y }} className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-50 via-rose-50 to-emerald-50 dark:from-violet-950/30 dark:via-rose-950/20 dark:to-emerald-950/30" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-violet-300/20 dark:bg-violet-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-emerald-300/20 dark:bg-emerald-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-rose-200/20 dark:bg-rose-500/5 rounded-full blur-3xl" />
      </motion.div>

      <motion.div style={{ opacity }} className="max-w-5xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-foreground/5 border border-border/50 text-sm text-muted-foreground mb-8">
            <Brain className="w-4 h-4" />
            A Comprehensive Guide to All Psychology
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight mb-6"
        >
          <span className="bg-gradient-to-r from-violet-600 via-rose-500 to-emerald-500 bg-clip-text text-transparent">
            The World of
          </span>
          <br />
          <span>Psychology</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-10 leading-relaxed"
        >
          From ancient philosophical inquiries to cutting-edge neuroscience, from the depths of the
          human unconscious to the surprising minds of octopuses and bees — explore the complete
          landscape of psychological science across all species and all eras.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <Button
            size="lg"
            onClick={() => document.getElementById("history")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-gradient-to-r from-violet-600 to-rose-500 hover:from-violet-700 hover:to-rose-600 text-white"
          >
            <History className="w-4 h-4 mr-2" />
            Explore the Timeline
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => document.getElementById("human")?.scrollIntoView({ behavior: "smooth" })}
          >
            <Layers className="w-4 h-4 mr-2" />
            Browse All Branches
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 max-w-3xl mx-auto"
        >
          {[
            { value: "3,500+", label: "Years of History" },
            { value: "12+", label: "Human Subfields" },
            { value: "8+", label: "Nonhuman Domains" },
            { value: "50+", label: "Key Milestones" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-violet-600 to-rose-500 bg-clip-text text-transparent">
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <ChevronDown className="w-6 h-6 text-muted-foreground" />
      </motion.div>
    </section>
  );
}

// ─── History Timeline ───────────────────────────────────────
function HistoryTimeline() {
  const [selectedEra, setSelectedEra] = useState<string | null>(null);

  return (
    <Section id="history" className="bg-gradient-to-b from-background to-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">
            <Clock className="w-3 h-3 mr-1" />
            Historical Journey
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">History of Psychology</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            From the earliest questions about the soul to modern neuroscience — trace the
            intellectual journey that shaped our understanding of the mind across 3,500 years.
          </p>
        </div>

        {/* Era Selector */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {timelineEras.map((era) => (
            <Button
              key={era.id}
              variant={selectedEra === era.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedEra(selectedEra === era.id ? null : era.id)}
              className="text-xs sm:text-sm"
            >
              {era.era}
              <span className="hidden sm:inline ml-1 text-muted-foreground/60">({era.period})</span>
            </Button>
          ))}
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Center line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-border md:-translate-x-0.5" />

          <div className="space-y-8">
            {timelineEras
              .filter((era) => !selectedEra || era.id === selectedEra)
              .map((era, eraIdx) => (
                <div key={era.id} className="space-y-6">
                  {/* Era Header */}
                  <div className="relative flex items-center justify-center">
                    <div className={`px-6 py-3 rounded-xl bg-gradient-to-r ${era.color} text-white font-bold text-lg shadow-lg`}>
                      {era.era}
                      <span className="ml-2 font-normal text-white/80 text-sm">{era.period}</span>
                    </div>
                  </div>

                  {/* Era Description */}
                  <p className="text-muted-foreground max-w-3xl mx-auto text-center text-sm leading-relaxed px-4">
                    {era.description}
                  </p>

                  {/* Events */}
                  <div className="space-y-4">
                    {era.events.map((event, eventIdx) => {
                      const isLeft = eventIdx % 2 === 0;
                      return (
                        <motion.div
                          key={eventIdx}
                          initial={{ opacity: 0, x: isLeft ? -20 : 20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true, margin: "-50px" }}
                          transition={{ duration: 0.5, delay: eventIdx * 0.05 }}
                          className={`relative flex items-start gap-4 pl-12 md:pl-0 ${
                            isLeft ? "md:flex-row" : "md:flex-row-reverse"
                          }`}
                        >
                          {/* Dot on timeline */}
                          <div className="absolute left-2.5 md:left-1/2 md:-translate-x-1/2 w-4 h-4 rounded-full bg-gradient-to-r from-violet-500 to-rose-500 border-2 border-background z-10 top-4" />

                          {/* Content */}
                          <div className={`flex-1 ${isLeft ? "md:pr-12 md:text-right" : "md:pl-12 md:text-left"}`}>
                            <Card className={`inline-block text-left ${era.hover} transition-colors duration-200`}>
                              <CardHeader className="pb-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <Badge variant="outline" className="font-mono text-xs">
                                    {event.year}
                                  </Badge>
                                  <CardTitle className="text-base">{event.title}</CardTitle>
                                </div>
                              </CardHeader>
                              <CardContent>
                                <p className="text-sm text-muted-foreground leading-relaxed">
                                  {event.description}
                                </p>
                              </CardContent>
                            </Card>
                          </div>

                          {/* Spacer for the other side */}
                          <div className="hidden md:block flex-1" />
                        </motion.div>
                      );
                    })}
                  </div>

                  {eraIdx < (selectedEra ? 0 : timelineEras.length - 1) && (
                    <Separator className="my-8" />
                  )}
                </div>
              ))}
          </div>
        </div>
      </div>
    </Section>
  );
}

// ─── Human Psychology ───────────────────────────────────────
function HumanPsychology() {
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = humanPsychologyBranches.filter(
    (b) =>
      b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.keyTopics.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <Section id="human" className="bg-gradient-to-b from-muted/30 to-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4">
            <User className="w-3 h-3 mr-1" />
            Human Psychology
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Branches of Human Psychology</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Psychology encompasses dozens of specialized subfields, each exploring different facets of
            the human mind and behavior. Explore the major branches that define the discipline today.
          </p>
        </div>

        {/* Search */}
        <div className="max-w-md mx-auto mb-8 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search branches, topics, or key figures..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Branch Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filtered.map((branch, idx) => {
            const Icon = iconMap[branch.icon] || Brain;
            const colors = getColor(branch.color);
            return (
              <motion.div
                key={branch.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.05 }}
              >
                <Card className={`h-full ${colors.hover} transition-colors duration-200 border-2 ${colors.border}`}>
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`p-2 rounded-lg ${colors.light}`}>
                        <Icon className={`w-5 h-5 ${colors.text}`} />
                      </div>
                      <CardTitle className="text-lg">{branch.name}</CardTitle>
                    </div>
                    <CardDescription className="leading-relaxed">{branch.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                          Key Topics
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {branch.keyTopics.map((topic) => (
                            <Badge key={topic} variant="secondary" className="text-xs font-normal">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                          Key Figures
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {branch.keyFigures.map((figure) => (
                            <Badge key={figure} className={`text-xs font-normal ${colors.badge}`}>
                              {figure}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Search className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p>No branches match your search. Try a different term.</p>
          </div>
        )}
      </div>
    </Section>
  );
}

// ─── Nonhuman Psychology ────────────────────────────────────
function NonhumanPsychology() {
  return (
    <Section id="nonhuman" className="bg-gradient-to-b from-background to-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4">
            <PawPrint className="w-3 h-3 mr-1" />
            Nonhuman Psychology
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">The Minds Beyond Humans</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            From the intricate societies of ants to the problem-solving brilliance of corvids, from
            the emotional lives of elephants to the distributed intelligence of octopuses — the
            animal kingdom is rich with cognitive sophistication that challenges our anthropocentric
            assumptions.
          </p>
        </div>

        <Accordion type="multiple" className="space-y-4">
          {nonhumanPsychology.map((field, idx) => {
            const Icon = iconMap[field.icon] || Bug;
            const colors = getColor(field.color);
            return (
              <motion.div
                key={field.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.05 }}
              >
                <AccordionItem
                  value={field.id}
                  className={`border-2 rounded-xl ${colors.border} overflow-hidden`}
                >
                  <AccordionTrigger className={`px-6 py-4 ${colors.hover} hover:no-underline`}>
                    <div className="flex items-center gap-3 text-left">
                      <div className={`p-2 rounded-lg ${colors.light}`}>
                        <Icon className={`w-5 h-5 ${colors.text}`} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{field.name}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-1">
                          {field.description.slice(0, 100)}...
                        </p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-6">
                    <p className="text-muted-foreground leading-relaxed mb-6">{field.description}</p>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                          Key Topics
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {field.keyTopics.map((topic) => (
                            <Badge key={topic} variant="secondary" className="text-xs font-normal">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                          Remarkable Examples
                        </p>
                        <ul className="space-y-2">
                          {field.examples.map((example) => (
                            <li key={example} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <ChevronRight className={`w-4 h-4 mt-0.5 shrink-0 ${colors.text}`} />
                              {example}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            );
          })}
        </Accordion>
      </div>
    </Section>
  );
}

// ─── Key Figures ────────────────────────────────────────────
function KeyFiguresSection() {
  return (
    <Section id="figures" className="bg-gradient-to-b from-muted/30 to-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4">
            <Star className="w-3 h-3 mr-1" />
            Pioneers & Visionaries
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Key Figures in Psychology</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            The thinkers who transformed our understanding of the mind — from the founders of major
            schools to the innovators who challenged and reshaped the discipline.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {keyFigures.map((figure, idx) => {
            const colors = getColor(figure.color);
            return (
              <motion.div
                key={figure.name}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.04 }}
              >
                <Card className={`h-full ${colors.hover} transition-colors duration-200`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full ${colors.bg} flex items-center justify-center text-white font-bold text-sm`}>
                        {figure.name.split(" ").map((n) => n[0]).join("")}
                      </div>
                      <div>
                        <CardTitle className="text-base">{figure.name}</CardTitle>
                        <p className="text-xs text-muted-foreground">{figure.years}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Badge className={`text-xs mb-2 ${colors.badge}`}>{figure.school}</Badge>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {figure.contribution}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}

// ─── Modern Frontiers ───────────────────────────────────────
function ModernFrontiers() {
  return (
    <Section id="modern" className="bg-gradient-to-b from-background to-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4">
            <Compass className="w-3 h-3 mr-1" />
            Cutting Edge
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Modern Frontiers</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Psychology is evolving faster than ever, integrating with neuroscience, AI, genetics,
            and global health. Explore the frontiers that will define the next chapter of
            psychological science.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {modernTopics.map((topic, idx) => {
            const Icon = iconMap[topic.icon] || Lightbulb;
            const colors = getColor(
              ["violet", "rose", "emerald", "amber", "cyan", "fuchsia", "teal", "orange"][idx % 8]
            );
            return (
              <motion.div
                key={topic.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.06 }}
              >
                <Card className={`h-full ${colors.hover} transition-colors duration-200`}>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className={`p-2.5 rounded-xl ${colors.light}`}>
                        <Icon className={`w-6 h-6 ${colors.text}`} />
                      </div>
                      <CardTitle className="text-lg">{topic.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed">{topic.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}

// ─── Footer ─────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="border-t bg-muted/30 py-12 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Brain className="w-5 h-5 text-violet-600 dark:text-violet-400" />
              <span className="font-bold text-lg">PsychWorld</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              A comprehensive exploration of all psychology — human and nonhuman, from the earliest
              philosophical inquiries to the cutting edge of modern science. Knowledge belongs to
              everyone.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Explore</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {[
                { id: "history", label: "History of Psychology" },
                { id: "human", label: "Human Psychology" },
                { id: "nonhuman", label: "Nonhuman Psychology" },
                { id: "figures", label: "Key Figures" },
                { id: "modern", label: "Modern Frontiers" },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => document.getElementById(item.id)?.scrollIntoView({ behavior: "smooth" })}
                    className="hover:text-foreground transition-colors"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">About This Project</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              This educational resource synthesizes information from across the entire field of
              psychology. Content is curated for accuracy and accessibility. All information is
              presented for educational purposes and should not replace professional psychological
              advice.
            </p>
          </div>
        </div>
        <Separator className="my-8" />
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>PsychWorld — A Comprehensive Guide to All Psychology</p>
          <p>Built with care for the pursuit of understanding the mind.</p>
        </div>
      </div>
    </footer>
  );
}

// ─── Scroll to Top Button ───────────────────────────────────
function ScrollToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-40 p-3 rounded-full bg-foreground text-background shadow-lg hover:shadow-xl transition-shadow"
        >
          <ArrowUp className="w-5 h-5" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}

// ─── Main Page ──────────────────────────────────────────────
export default function Home() {
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const sections = ["hero", "history", "human", "nonhuman", "figures", "modern"];
    const observers: IntersectionObserver[] = [];

    sections.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActiveSection(id);
        },
        { rootMargin: "-30% 0px -60% 0px" }
      );
      obs.observe(el);
      observers.push(obs);
    });

    return () => observers.forEach((obs) => obs.disconnect());
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation activeSection={activeSection} />
      <main className="flex-1">
        <HeroSection />
        <HistoryTimeline />
        <HumanPsychology />
        <NonhumanPsychology />
        <KeyFiguresSection />
        <ModernFrontiers />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}
